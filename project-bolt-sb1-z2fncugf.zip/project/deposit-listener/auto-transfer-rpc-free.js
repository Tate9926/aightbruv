import { Connection, Keypair, PublicKey, SystemProgram, Transaction, LAMPORTS_PER_SOL } from '@solana/web3.js'
import { mnemonicToSeedSync } from 'bip39'
import { derivePath } from 'ed25519-hd-key'
import { createClient } from '@supabase/supabase-js'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'
import fetch from 'node-fetch'
import dotenv from 'dotenv'

// Polyfill fetch for Node.js
if (!globalThis.fetch) {
  globalThis.fetch = fetch
}

// Get current directory for ES modules
const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

// Load environment variables
dotenv.config({ path: join(__dirname, '.env') })

class SolanaRPCFreeTransfer {
  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        },
        global: {
          fetch: fetch
        }
      }
    )
    
    // Collection wallet address (where all funds go)
    this.collectionAddress = process.env.COLLECTION_WALLET_ADDRESS || '6MCvSMpgu7bM5tS1wS5HPrtST3fZfb1NwRp8UYZhyKfc'
    
    console.log('🚀 RPC-Free Solana Transfer Service initialized')
    console.log(`📦 Collection address: ${this.collectionAddress}`)
  }

  // Generate keypair from mnemonic using Phantom's derivation path
  generateKeypairFromMnemonic(mnemonic, accountIndex) {
    try {
      // Convert mnemonic to seed
      const seed = mnemonicToSeedSync(mnemonic)
      
      // Phantom uses: m/44'/501'/0'/0' (account level derivation)
      const derivationPath = `m/44'/501'/${accountIndex}'/0'`
      
      console.log(`🔑 Deriving keypair for account ${accountIndex} using path: ${derivationPath}`)
      
      // Derive the key
      const derivedSeed = derivePath(derivationPath, seed.toString('hex')).key
      
      // Create keypair from derived seed
      const keypair = Keypair.fromSeed(derivedSeed)
      
      console.log(`✅ Generated address: ${keypair.publicKey.toBase58()}`)
      
      return keypair
    } catch (error) {
      console.error('❌ Error generating keypair:', error)
      throw error
    }
  }

  // Create and serialize transaction WITHOUT sending it
  async createTransferTransaction(fromKeypair, toAddress, amountLamports) {
    try {
      const toPublicKey = new PublicKey(toAddress)
      
      // Create transfer instruction
      const transferInstruction = SystemProgram.transfer({
        fromPubkey: fromKeypair.publicKey,
        toPubkey: toPublicKey,
        lamports: amountLamports
      })
      
      // Create transaction (we'll need a recent blockhash, but we can use a dummy one for now)
      const transaction = new Transaction()
      transaction.add(transferInstruction)
      transaction.feePayer = fromKeypair.publicKey
      
      // For now, we'll use a placeholder blockhash
      // In a real implementation, you'd get this from the WebSocket or cache it
      transaction.recentBlockhash = '11111111111111111111111111111111'
      
      // Sign the transaction
      transaction.sign(fromKeypair)
      
      // Serialize the transaction
      const serializedTransaction = transaction.serialize()
      
      console.log(`📦 Created transaction: ${serializedTransaction.toString('base64')}`)
      
      return {
        transaction: serializedTransaction,
        signature: transaction.signature?.toString('hex') || 'unknown'
      }
      
    } catch (error) {
      console.error('❌ Error creating transaction:', error)
      throw error
    }
  }

  // Process transfer using known balance from WebSocket data
  async processTransferWithKnownBalance(userId, accountIndex, balanceLamports, reason = 'Auto sweep') {
    try {
      const masterMnemonic = process.env.MASTER_MNEMONIC
      if (!masterMnemonic) {
        throw new Error('MASTER_MNEMONIC not configured')
      }
      
      console.log(`🎯 Processing transfer for user ${userId} (account ${accountIndex})`)
      console.log(`💰 Known balance: ${balanceLamports} lamports (${(balanceLamports / LAMPORTS_PER_SOL).toFixed(9)} SOL)`)
      
      // Generate keypair for this user's account
      const userKeypair = this.generateKeypairFromMnemonic(masterMnemonic, accountIndex)
      
      // Calculate transfer amount (leave some for transaction fees)
      const transactionFee = 5000 // 5000 lamports = 0.000005 SOL
      const transferAmount = Math.max(0, balanceLamports - transactionFee)
      
      if (transferAmount <= 0) {
        console.log('⚠️ Insufficient balance to cover transaction fee')
        return null
      }
      
      console.log(`📤 Will transfer: ${transferAmount} lamports (${(transferAmount / LAMPORTS_PER_SOL).toFixed(9)} SOL)`)
      console.log(`💸 Transaction fee: ${transactionFee} lamports (${(transactionFee / LAMPORTS_PER_SOL).toFixed(9)} SOL)`)
      
      // Create the transaction (serialized, ready to broadcast)
      const { transaction, signature } = await this.createTransferTransaction(
        userKeypair,
        this.collectionAddress,
        transferAmount
      )
      
      console.log(`✅ Transaction created successfully!`)
      console.log(`🔗 Transaction signature: ${signature}`)
      console.log(`💰 Amount: ${(transferAmount / LAMPORTS_PER_SOL).toFixed(9)} SOL`)
      console.log(`📍 From: ${userKeypair.publicKey.toBase58()}`)
      console.log(`📍 To: ${this.collectionAddress}`)
      
      // Log the transfer in database
      try {
        await this.supabase
          .from('transfer_logs')
          .insert({
            user_id: userId,
            from_address: userKeypair.publicKey.toBase58(),
            to_address: this.collectionAddress,
            amount_sol: transferAmount / LAMPORTS_PER_SOL,
            transaction_hash: signature,
            reason: reason,
            status: 'created', // Not sent yet, just created
            serialized_transaction: transaction.toString('base64')
          })
      } catch (dbError) {
        console.log('⚠️ Failed to log transfer to database:', dbError.message)
      }
      
      return {
        signature,
        amount: transferAmount,
        amountSOL: transferAmount / LAMPORTS_PER_SOL,
        fee: transactionFee,
        from: userKeypair.publicKey.toBase58(),
        to: this.collectionAddress,
        serializedTransaction: transaction.toString('base64')
      }
      
    } catch (error) {
      console.error(`❌ Failed to process transfer for user ${userId}:`, error)
      throw error
    }
  }

  // Listen for deposit notifications and create transfer transactions
  async startTransferListener() {
    console.log('👂 Starting RPC-free transfer listener...')
    
    // Subscribe to deposit notifications
    const channel = this.supabase
      .channel('deposit-notifications')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'pending_deposits',
        filter: 'network=eq.solana'
      }, async (payload) => {
        console.log('🔔 New deposit detected:', payload.new)
        
        try {
          const deposit = payload.new
          
          // Get user's account index
          const { data: profile } = await this.supabase
            .from('profiles')
            .select('account_index')
            .eq('id', deposit.user_id)
            .single()

          const accountIndex = profile?.account_index || 0
          
          // Convert USD amount back to lamports (approximate)
          const estimatedLamports = Math.floor(deposit.amount_crypto * LAMPORTS_PER_SOL)
          
          console.log(`🚀 Creating transfer transaction for deposit ${deposit.id}`)
          
          const result = await this.processTransferWithKnownBalance(
            deposit.user_id,
            accountIndex,
            estimatedLamports,
            `Auto-sweep for deposit ${deposit.id}`
          )
          
          if (result) {
            console.log(`✅ Transfer transaction created: ${result.amountSOL.toFixed(9)} SOL`)
            console.log(`📦 Serialized transaction ready for broadcast`)
          }
          
        } catch (error) {
          console.error('❌ Auto-transfer failed:', error)
        }
      })
      .subscribe()

    console.log('✅ RPC-free transfer listener active!')
    return channel
  }
}

// CLI interface
if (import.meta.url === `file://${process.argv[1]}`) {
  const autoTransfer = new SolanaRPCFreeTransfer()
  
  const command = process.argv[2]
  
  switch (command) {
    case 'create-transfer':
      const userId = process.argv[3]
      const accountIndex = parseInt(process.argv[4]) || 0
      const balanceLamports = parseInt(process.argv[5]) || 1000000 // 0.001 SOL default
      
      if (!userId) {
        console.error('❌ Usage: node auto-transfer-rpc-free.js create-transfer <user_id> [account_index] [balance_lamports]')
        process.exit(1)
      }
      
      console.log(`🎯 Creating transfer for user ${userId}...`)
      autoTransfer.processTransferWithKnownBalance(userId, accountIndex, balanceLamports, 'Manual transfer')
        .then(result => {
          console.log('✅ Transfer created:', result)
          process.exit(0)
        })
        .catch(error => {
          console.error('❌ Transfer creation failed:', error)
          process.exit(1)
        })
      break
      
    case 'listen':
      console.log('👂 Starting RPC-free transfer listener...')
      autoTransfer.startTransferListener()
        .then(() => {
          console.log('✅ Listener started, press Ctrl+C to stop')
        })
        .catch(error => {
          console.error('❌ Failed to start listener:', error)
          process.exit(1)
        })
      break
      
    default:
      console.log('📖 Usage:')
      console.log('  node auto-transfer-rpc-free.js create-transfer <user_id> [account_index] [balance_lamports]')
      console.log('  node auto-transfer-rpc-free.js listen                    # Start transfer listener')
      console.log('')
      console.log('Examples:')
      console.log('  node auto-transfer-rpc-free.js create-transfer 28e19fe0-e11e-43fe-b178-a0af314334da 1 1000000')
      console.log('  node auto-transfer-rpc-free.js listen')
      break
  }
}

export { SolanaRPCFreeTransfer }