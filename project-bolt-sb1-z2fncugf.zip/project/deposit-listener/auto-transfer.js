import { Connection, Keypair, PublicKey, SystemProgram, Transaction, sendAndConfirmTransaction, LAMPORTS_PER_SOL } from '@solana/web3.js'
import { mnemonicToSeedSync } from 'bip39'
import { derivePath } from 'ed25519-hd-key'
import { createClient } from '@supabase/supabase-js'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'
import fetch from 'node-fetch'
import dotenv from 'dotenv'

// Polyfill fetch for Node.js
if (!globalThis.fetch) {
  globalThis.fetch = fetch
}

// Get current directory for ES modules
const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

// Load environment variables
dotenv.config({ path: join(__dirname, '.env') })

class SolanaAutoTransfer {
  constructor() {
    this.connection = new Connection(
      process.env.SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com',
      'confirmed'
    )
    
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        },
        global: {
          fetch: fetch
        }
      }
    )
    
    // Collection wallet address (where all funds go)
    this.collectionAddress = process.env.COLLECTION_WALLET_ADDRESS || '6MCvSMpgu7bM5tS1wS5HPrtST3fZfb1NwRp8UYZhyKfc'
    
    console.log('🚀 Solana Auto Transfer Service initialized')
    console.log(`📦 Collection address: ${this.collectionAddress}`)
  }

  // Generate keypair from mnemonic using Phantom's derivation path
  generateKeypairFromMnemonic(mnemonic, accountIndex) {
    try {
      // Convert mnemonic to seed
      const seed = mnemonicToSeedSync(mnemonic)
      
      // Phantom uses: m/44'/501'/0'/0' (account level derivation)
      const derivationPath = `m/44'/501'/${accountIndex}'/0'`
      
      console.log(`🔑 Deriving keypair for account ${accountIndex} using path: ${derivationPath}`)
      
      // Derive the key
      const derivedSeed = derivePath(derivationPath, seed.toString('hex')).key
      
      // Create keypair from derived seed
      const keypair = Keypair.fromSeed(derivedSeed)
      
      console.log(`✅ Generated address: ${keypair.publicKey.toBase58()}`)
      
      return keypair
    } catch (error) {
      console.error('❌ Error generating keypair:', error)
      throw error
    }
  }

  // Transfer all available SOL from source to collection address
  async transferAllFunds(sourceKeypair, reason = 'Auto sweep') {
    try {
      const sourceAddress = sourceKeypair.publicKey
      const collectionPublicKey = new PublicKey(this.collectionAddress)
      
      console.log(`🔄 Starting transfer from ${sourceAddress.toBase58()}`)
      console.log(`📍 To collection: ${this.collectionAddress}`)
      console.log(`📝 Reason: ${reason}`)
      
      // Get current balance
      const balance = await this.connection.getBalance(sourceAddress)
      console.log(`💰 Current balance: ${balance} lamports (${(balance / LAMPORTS_PER_SOL).toFixed(9)} SOL)`)
      
      if (balance === 0) {
        console.log('⚠️ No balance to transfer')
        return null
      }
      
      // Get recent blockhash
      const { blockhash } = await this.connection.getLatestBlockhash('confirmed')
      
      // Create a dummy transaction to estimate fees
      const dummyTransaction = new Transaction({
        feePayer: sourceAddress,
        recentBlockhash: blockhash
      }).add(
        SystemProgram.transfer({
          fromPubkey: sourceAddress,
          toPubkey: collectionPublicKey,
          lamports: balance
        })
      )
      
      // Estimate transaction fee
      const feeEstimate = await this.connection.getFeeForMessage(
        dummyTransaction.compileMessage(),
        'confirmed'
      )
      
      const transactionFee = feeEstimate.value || 5000 // Default 5000 lamports if estimation fails
      console.log(`💸 Estimated fee: ${transactionFee} lamports (${(transactionFee / LAMPORTS_PER_SOL).toFixed(9)} SOL)`)
      
      // Calculate amount to transfer (balance minus fee)
      const transferAmount = balance - transactionFee
      
      if (transferAmount <= 0) {
        console.log('⚠️ Insufficient balance to cover transaction fee')
        return null
      }
      
      console.log(`📤 Transferring: ${transferAmount} lamports (${(transferAmount / LAMPORTS_PER_SOL).toFixed(9)} SOL)`)
      
      // Create the actual transfer transaction
      const transaction = new Transaction({
        feePayer: sourceAddress,
        recentBlockhash: blockhash
      }).add(
        SystemProgram.transfer({
          fromPubkey: sourceAddress,
          toPubkey: collectionPublicKey,
          lamports: transferAmount
        })
      )
      
      // Send and confirm transaction
      const signature = await sendAndConfirmTransaction(
        this.connection,
        transaction,
        [sourceKeypair],
        {
          commitment: 'confirmed',
          preflightCommitment: 'confirmed'
        }
      )
      
      console.log(`✅ Transfer successful!`)
      console.log(`🔗 Transaction: ${signature}`)
      console.log(`💰 Transferred: ${(transferAmount / LAMPORTS_PER_SOL).toFixed(9)} SOL`)
      
      return {
        signature,
        amount: transferAmount,
        amountSOL: transferAmount / LAMPORTS_PER_SOL,
        fee: transactionFee,
        from: sourceAddress.toBase58(),
        to: this.collectionAddress
      }
      
    } catch (error) {
      console.error('❌ Transfer failed:', error)
      throw error
    }
  }

  // Process transfer for a specific user address
  async processTransferForUser(userId, accountIndex, reason = 'Deposit sweep') {
    try {
      const masterMnemonic = process.env.MASTER_MNEMONIC
      if (!masterMnemonic) {
        throw new Error('MASTER_MNEMONIC not configured')
      }
      
      console.log(`🎯 Processing transfer for user ${userId} (account ${accountIndex})`)
      
      // Generate keypair for this user's account
      const userKeypair = this.generateKeypairFromMnemonic(masterMnemonic, accountIndex)
      
      // Transfer all funds
      const result = await this.transferAllFunds(userKeypair, reason)
      
      if (result) {
        console.log(`✅ Successfully swept ${result.amountSOL.toFixed(9)} SOL from user ${userId}`)
        
        // Log the transfer in database (optional)
        try {
          await this.supabase
            .from('transfer_logs')
            .insert({
              user_id: userId,
              from_address: result.from,
              to_address: result.to,
              amount_sol: result.amountSOL,
              transaction_hash: result.signature,
              reason: reason,
              status: 'completed'
            })
        } catch (dbError) {
          console.log('⚠️ Failed to log transfer to database:', dbError.message)
        }
      }
      
      return result
      
    } catch (error) {
      console.error(`❌ Failed to process transfer for user ${userId}:`, error)
      throw error
    }
  }

  // Sweep all user addresses
  async sweepAllAddresses() {
    try {
      console.log('🧹 Starting sweep of all user addresses...')
      
      // Get all user addresses from database
      const { data: userAddresses, error } = await this.supabase
        .rpc('get_user_addresses_for_network', { network_name: 'solana' })

      if (error) {
        throw new Error(`Failed to get user addresses: ${error.message}`)
      }

      console.log(`📊 Found ${userAddresses?.length || 0} user addresses to sweep`)

      let totalSwept = 0
      let successfulSweeps = 0

      for (const userAddress of userAddresses || []) {
        try {
          // Get user's account index from profiles table
          const { data: profile } = await this.supabase
            .from('profiles')
            .select('account_index')
            .eq('id', userAddress.user_id)
            .single()

          const accountIndex = profile?.account_index || 0
          
          const result = await this.processTransferForUser(
            userAddress.user_id, 
            accountIndex, 
            'Scheduled sweep'
          )
          
          if (result) {
            totalSwept += result.amountSOL
            successfulSweeps++
          }
          
          // Small delay between transfers
          await new Promise(resolve => setTimeout(resolve, 1000))
          
        } catch (error) {
          console.error(`❌ Failed to sweep user ${userAddress.user_id}:`, error.message)
        }
      }
      
      console.log(`✅ Sweep completed!`)
      console.log(`📊 Successful sweeps: ${successfulSweeps}`)
      console.log(`💰 Total swept: ${totalSwept.toFixed(9)} SOL`)
      
      return {
        totalSwept,
        successfulSweeps,
        totalAddresses: userAddresses?.length || 0
      }
      
    } catch (error) {
      console.error('❌ Sweep all addresses failed:', error)
      throw error
    }
  }

  // Listen for deposit notifications and auto-transfer
  async startAutoTransferListener() {
    console.log('👂 Starting auto-transfer listener...')
    
    // Subscribe to deposit notifications from the main deposit listener
    const channel = this.supabase
      .channel('deposit-notifications')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'pending_deposits',
        filter: 'network=eq.solana'
      }, async (payload) => {
        console.log('🔔 New deposit detected:', payload.new)
        
        try {
          const deposit = payload.new
          
          // Get user's account index
          const { data: profile } = await this.supabase
            .from('profiles')
            .select('account_index')
            .eq('id', deposit.user_id)
            .single()

          const accountIndex = profile?.account_index || 0
          
          // Auto-transfer funds
          console.log(`🚀 Auto-transferring funds for deposit ${deposit.id}`)
          
          await this.processTransferForUser(
            deposit.user_id,
            accountIndex,
            `Auto-sweep for deposit ${deposit.id}`
          )
          
        } catch (error) {
          console.error('❌ Auto-transfer failed:', error)
        }
      })
      .subscribe()

    console.log('✅ Auto-transfer listener active!')
    return channel
  }
}

// CLI interface
if (import.meta.url === `file://${process.argv[1]}`) {
  const autoTransfer = new SolanaAutoTransfer()
  
  const command = process.argv[2]
  
  switch (command) {
    case 'sweep-all':
      console.log('🧹 Manual sweep of all addresses...')
      autoTransfer.sweepAllAddresses()
        .then(result => {
          console.log('✅ Sweep completed:', result)
          process.exit(0)
        })
        .catch(error => {
          console.error('❌ Sweep failed:', error)
          process.exit(1)
        })
      break
      
    case 'sweep-user':
      const userId = process.argv[3]
      const accountIndex = parseInt(process.argv[4]) || 0
      
      if (!userId) {
        console.error('❌ Usage: node auto-transfer.js sweep-user <user_id> [account_index]')
        process.exit(1)
      }
      
      console.log(`🎯 Manual sweep for user ${userId}...`)
      autoTransfer.processTransferForUser(userId, accountIndex, 'Manual sweep')
        .then(result => {
          console.log('✅ User sweep completed:', result)
          process.exit(0)
        })
        .catch(error => {
          console.error('❌ User sweep failed:', error)
          process.exit(1)
        })
      break
      
    case 'listen':
      console.log('👂 Starting auto-transfer listener...')
      autoTransfer.startAutoTransferListener()
        .then(() => {
          console.log('✅ Listener started, press Ctrl+C to stop')
        })
        .catch(error => {
          console.error('❌ Failed to start listener:', error)
          process.exit(1)
        })
      break
      
    default:
      console.log('📖 Usage:')
      console.log('  node auto-transfer.js sweep-all              # Sweep all user addresses')
      console.log('  node auto-transfer.js sweep-user <user_id>   # Sweep specific user')
      console.log('  node auto-transfer.js listen                 # Start auto-transfer listener')
      break
  }
}

export { SolanaAutoTransfer }