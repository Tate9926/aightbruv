// Re-export the new modular SnakeGame component
export { SnakeGame } from './game/SnakeGame'