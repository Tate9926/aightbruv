/*
  # Create withdrawals table for cash out functionality

  1. New Tables
    - `withdrawals`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `amount` (numeric, withdrawal amount in crypto)
      - `network` (text, crypto network: ethereum/tron/solana)
      - `withdrawal_address` (text, destination address)
      - `network_fee` (numeric, blockchain network fee)
      - `total_amount` (numeric, amount + fee)
      - `usd_amount` (numeric, equivalent USD amount)
      - `status` (text, withdrawal status)
      - `transaction_hash` (text, blockchain transaction hash)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `processed_at` (timestamp, when withdrawal was completed)

  2. Security
    - Enable RLS on `withdrawals` table
    - Add policies for users to manage their own withdrawals
    - Add constraints for valid status values

  3. Indexes
    - Index on user_id for fast user withdrawal queries
    - Index on status for admin queries
    - Index on created_at for chronological sorting
*/

-- Create withdrawals table
CREATE TABLE IF NOT EXISTS withdrawals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  amount numeric(20,8) NOT NULL CHECK (amount > 0),
  network text NOT NULL CHECK (network IN ('ethereum', 'tron', 'solana')),
  withdrawal_address text NOT NULL,
  network_fee numeric(20,8) NOT NULL DEFAULT 0,
  total_amount numeric(20,8) NOT NULL CHECK (total_amount > 0),
  usd_amount numeric(10,2) NOT NULL CHECK (usd_amount > 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'cancelled')),
  transaction_hash text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  processed_at timestamptz
);

-- Enable RLS
ALTER TABLE withdrawals ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can insert own withdrawals"
  ON withdrawals
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can read own withdrawals"
  ON withdrawals
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update own pending withdrawals"
  ON withdrawals
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid() AND status = 'pending')
  WITH CHECK (user_id = auth.uid());

-- Create indexes
CREATE INDEX IF NOT EXISTS withdrawals_user_id_idx ON withdrawals(user_id);
CREATE INDEX IF NOT EXISTS withdrawals_status_idx ON withdrawals(status);
CREATE INDEX IF NOT EXISTS withdrawals_created_at_idx ON withdrawals(created_at DESC);
CREATE INDEX IF NOT EXISTS withdrawals_network_idx ON withdrawals(network);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_withdrawals_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_withdrawals_updated_at
  BEFORE UPDATE ON withdrawals
  FOR EACH ROW
  EXECUTE FUNCTION update_withdrawals_updated_at();

-- Create function to get user withdrawal history
CREATE OR REPLACE FUNCTION get_user_withdrawals(target_user_id uuid)
RETURNS TABLE (
  id uuid,
  amount numeric,
  network text,
  withdrawal_address text,
  network_fee numeric,
  total_amount numeric,
  usd_amount numeric,
  status text,
  transaction_hash text,
  created_at timestamptz,
  processed_at timestamptz
) 
SECURITY DEFINER
AS $$
BEGIN
  -- Check if the requesting user is the same as target user
  IF auth.uid() != target_user_id THEN
    RAISE EXCEPTION 'Access denied';
  END IF;

  RETURN QUERY
  SELECT 
    w.id,
    w.amount,
    w.network,
    w.withdrawal_address,
    w.network_fee,
    w.total_amount,
    w.usd_amount,
    w.status,
    w.transaction_hash,
    w.created_at,
    w.processed_at
  FROM withdrawals w
  WHERE w.user_id = target_user_id
  ORDER BY w.created_at DESC;
END;
$$ LANGUAGE plpgsql;