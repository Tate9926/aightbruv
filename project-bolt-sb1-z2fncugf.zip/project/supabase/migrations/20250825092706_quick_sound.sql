/*
  # Add withdrawal processing triggers and functions

  1. Functions
    - `update_withdrawals_updated_at()` - Updates the updated_at timestamp
    - `validate_withdrawal_amount()` - Validates withdrawal amounts and balances
    
  2. Triggers
    - Updates updated_at on withdrawal record changes
    - Validates withdrawal amounts before processing
    
  3. Security
    - Additional validation for withdrawal processing
    - Audit trail for all withdrawal operations
*/

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_withdrawals_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to validate withdrawal amounts
CREATE OR REPLACE FUNCTION validate_withdrawal_amount()
RETURNS TRIGGER AS $$
DECLARE
  user_balance NUMERIC;
BEGIN
  -- Get user's current balance
  SELECT total_winnings INTO user_balance
  FROM profiles
  WHERE id = NEW.user_id;
  
  -- Check if user has sufficient balance
  IF user_balance < NEW.usd_amount THEN
    RAISE EXCEPTION 'Insufficient balance. Available: %, Required: %', user_balance, NEW.usd_amount;
  END IF;
  
  -- Validate minimum withdrawal amounts
  IF NEW.network = 'ethereum' AND NEW.amount < 0.01 THEN
    RAISE EXCEPTION 'Minimum Ethereum withdrawal is 0.01 ETH';
  END IF;
  
  IF NEW.network = 'tron' AND NEW.amount < 10 THEN
    RAISE EXCEPTION 'Minimum Tron withdrawal is 10 TRX';
  END IF;
  
  IF NEW.network = 'solana' AND NEW.amount < 0.001 THEN
    RAISE EXCEPTION 'Minimum Solana withdrawal is 0.001 SOL';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
DROP TRIGGER IF EXISTS update_withdrawals_updated_at ON withdrawals;
CREATE TRIGGER update_withdrawals_updated_at
  BEFORE UPDATE ON withdrawals
  FOR EACH ROW
  EXECUTE FUNCTION update_withdrawals_updated_at();

DROP TRIGGER IF EXISTS validate_withdrawal_amount ON withdrawals;
CREATE TRIGGER validate_withdrawal_amount
  BEFORE INSERT ON withdrawals
  FOR EACH ROW
  EXECUTE FUNCTION validate_withdrawal_amount();

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS withdrawals_user_id_idx ON withdrawals(user_id);
CREATE INDEX IF NOT EXISTS withdrawals_status_idx ON withdrawals(status);
CREATE INDEX IF NOT EXISTS withdrawals_network_idx ON withdrawals(network);
CREATE INDEX IF NOT EXISTS withdrawals_created_at_idx ON withdrawals(created_at DESC);