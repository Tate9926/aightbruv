/*
  # Create Affiliate System

  1. New Tables
    - `affiliate_codes`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to profiles)
      - `code` (text, unique)
      - `created_at` (timestamp)
    - `affiliate_referrals`
      - `id` (uuid, primary key)
      - `referrer_id` (uuid, foreign key to profiles)
      - `referred_id` (uuid, foreign key to profiles)
      - `commission_earned` (numeric)
      - `commission_paid` (boolean)
      - `first_game_amount` (numeric)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for users to manage their own affiliate data
*/

-- Create affiliate_codes table
CREATE TABLE IF NOT EXISTS affiliate_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  code text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create affiliate_referrals table
CREATE TABLE IF NOT EXISTS affiliate_referrals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  referred_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  commission_earned numeric(10,2) NOT NULL DEFAULT 0,
  commission_paid boolean DEFAULT false,
  first_game_amount numeric(10,2) NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(referred_id) -- Each user can only be referred once
);

-- Enable RLS
ALTER TABLE affiliate_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE affiliate_referrals ENABLE ROW LEVEL SECURITY;

-- Policies for affiliate_codes
CREATE POLICY "Users can manage own affiliate codes"
  ON affiliate_codes
  FOR ALL
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Policies for affiliate_referrals
CREATE POLICY "Users can read own referral data"
  ON affiliate_referrals
  FOR SELECT
  TO authenticated
  USING (referrer_id = auth.uid());

CREATE POLICY "System can manage referrals"
  ON affiliate_referrals
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add indexes
CREATE INDEX IF NOT EXISTS affiliate_codes_user_id_idx ON affiliate_codes(user_id);
CREATE INDEX IF NOT EXISTS affiliate_codes_code_idx ON affiliate_codes(code);
CREATE INDEX IF NOT EXISTS affiliate_referrals_referrer_id_idx ON affiliate_referrals(referrer_id);
CREATE INDEX IF NOT EXISTS affiliate_referrals_referred_id_idx ON affiliate_referrals(referred_id);

-- Function to get or create affiliate code
CREATE OR REPLACE FUNCTION get_or_create_affiliate_code(p_user_id uuid, p_code text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  existing_code text;
BEGIN
  -- Check if user already has a code
  SELECT code INTO existing_code
  FROM affiliate_codes
  WHERE user_id = p_user_id;
  
  IF existing_code IS NOT NULL THEN
    RETURN existing_code;
  END IF;
  
  -- Create new code
  INSERT INTO affiliate_codes (user_id, code)
  VALUES (p_user_id, p_code)
  ON CONFLICT (code) DO NOTHING;
  
  -- Return the code (might be different if there was a conflict)
  SELECT code INTO existing_code
  FROM affiliate_codes
  WHERE user_id = p_user_id;
  
  RETURN COALESCE(existing_code, p_code);
END;
$$;

-- Function to process affiliate commission
CREATE OR REPLACE FUNCTION process_affiliate_commission(
  p_referred_user_id uuid,
  p_bet_amount numeric
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  referrer_user_id uuid;
  commission_amount numeric;
  existing_referral_id uuid;
BEGIN
  -- Check if this user was referred and hasn't been paid commission yet
  SELECT referrer_id, id INTO referrer_user_id, existing_referral_id
  FROM affiliate_referrals
  WHERE referred_id = p_referred_user_id AND commission_paid = false;
  
  IF referrer_user_id IS NULL THEN
    RETURN false; -- No referral or already paid
  END IF;
  
  -- Calculate 10% commission
  commission_amount := p_bet_amount * 0.10;
  
  -- Update referral record
  UPDATE affiliate_referrals
  SET 
    commission_earned = commission_amount,
    commission_paid = true,
    first_game_amount = p_bet_amount
  WHERE id = existing_referral_id;
  
  -- Add commission to referrer's balance
  UPDATE profiles
  SET balance = balance + commission_amount
  WHERE id = referrer_user_id;
  
  RETURN true;
END;
$$;

-- Function to get affiliate stats
CREATE OR REPLACE FUNCTION get_affiliate_stats(p_user_id uuid)
RETURNS TABLE(
  total_users integer,
  total_earnings numeric
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COUNT(*)::integer as total_users,
    COALESCE(SUM(commission_earned), 0) as total_earnings
  FROM affiliate_referrals
  WHERE referrer_id = p_user_id AND commission_paid = true;
END;
$$;