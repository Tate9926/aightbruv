/*
  # Update Crypto Wallets to Use Sections

  1. Changes
    - Add section_id column to crypto_addresses table
    - Update user_wallets to reference section_id instead of individual addresses
    - Create function to assign addresses by section
    - Populate sample data with sections

  2. Structure
    - Each section contains one ETH and one TRX address
    - Solana addresses remain individual (as they're from your CSV)
    - Users get assigned to a section for ETH/TRX, plus individual SOL address

  3. Security
    - Maintain RLS policies
    - Update triggers for new assignment logic
*/

-- Add section_id column to crypto_addresses
ALTER TABLE crypto_addresses ADD COLUMN section_id integer;

-- Update user_wallets structure
ALTER TABLE user_wallets DROP COLUMN ethereum_address;
ALTER TABLE user_wallets DROP COLUMN tron_address;
ALTER TABLE user_wallets ADD COLUMN section_id integer;

-- Create index for better performance
CREATE INDEX idx_crypto_addresses_section ON crypto_addresses(section_id, network);
CREATE INDEX idx_crypto_addresses_available ON crypto_addresses(is_assigned, section_id) WHERE section_id IS NOT NULL;

-- Clear existing data to start fresh
DELETE FROM crypto_addresses;

-- Insert sample ETH/TRX address sections (10 sections)
INSERT INTO crypto_addresses (address, network, section_id, is_assigned) VALUES
-- Section 1
('0x742d35Cc6634C0532925a3b8D4C9db96590c4C87', 'ethereum', 1, false),
('TLsV52sRDL79HXGog9zC2hTrdP59qnqkMh', 'tron', 1, false),

-- Section 2  
('0x8ba1f109551bD432803012645Hac136c82C', 'ethereum', 2, false),
('TQn9Y5sRDL79HXGog9zC2hTrdP59qnqkMi', 'tron', 2, false),

-- Section 3
('0x9ca2f209661cE543914356789Iac246d93D', 'ethereum', 3, false),
('TRo8Z6tSEL89IYHph0aC3iTseQ69rorlNj', 'tron', 3, false),

-- Section 4
('0xAdb3g319772dF654025467890Jbd357e04E', 'ethereum', 4, false),
('TSp9A7uTFL99JZIqi1bD4jUsfR79spsmOk', 'tron', 4, false),

-- Section 5
('0xBec4h429883eG765136578901Kce468f15F', 'ethereum', 5, false),
('TTq0B8vUGM00KaJrj2cE5kVtgS89tqtnPl', 'tron', 5, false),

-- Section 6
('0xCfd5i539994fH876247689012Ldf579g26G', 'ethereum', 6, false),
('TUr1C9wVHN11LbKsk3dF6lWuhT90urvoQm', 'tron', 6, false),

-- Section 7
('0xDge6j640005gI987358790123Meg680h37H', 'ethereum', 7, false),
('TVs2D0xWIO22McL tl4eG7mXviU01vswpRn', 'tron', 7, false),

-- Section 8
('0xEhf7k751116hJ098469801234Nfh791i48I', 'ethereum', 8, false),
('TWt3E1yXJP33NdMum5fH8nYwjV12wstxSo', 'tron', 8, false),

-- Section 9
('0xFig8l862227iK109570912345Ogi802j59J', 'ethereum', 9, false),
('TXu4F2zYKQ44OeNvn6gI9oZxkW23xturTp', 'tron', 9, false),

-- Section 10
('0xGjh9m973338jL210681023456Phj913k60K', 'ethereum', 10, false),
('TYv5G30ZLR55PfOwp7hJ0paymX34yuvsSq', 'tron', 10, false);

-- Insert Solana addresses (no sections, individual assignment)
INSERT INTO crypto_addresses (address, network, is_assigned) VALUES
('6MCvSMpgu7bM5tS1wS5HPrtST3fZfb1NwRp8UYZhyKfc', 'solana', false),
('5bnUQiVv3ST8GXQq54oiQy6LfbaEC74j3Y8sbFicQSc8', 'solana', false),
('GczBMftDnDGfbbxxhT9PLvtra7yGSzbHL5FcxXv58x9b', 'solana', false),
('GtmoTTcuFbWxqk4AXMpCNv8KfbyR61fUeD6J8PN2GhGE', 'solana', false),
('AtJpTTbX3sGhDb7a9DxfcBk1ZaUTGa9wLj8fhFbgJC7S', 'solana', false),
('2FSki4MiXmRkfYmzw3uNogMfyVW6w9QysFvc6KFpbS2R', 'solana', false),
('9RcHVFqmaKsNecDJgA5XjYrgHgKytyniu8zANhKtgKfC', 'solana', false),
('2JDav5YSM15MDF8hDpwtcBC9F1GWh9Y8x1PzAYr2rZ2t', 'solana', false),
('ACTkBxRZHjaWKkLCgvNPdPFexXcAigRKi62SEzLFEgms', 'solana', false),
('EbFdQyiQ4tA6B9Bt1FuRaW1AVrr8MDecRFVQKrfnY7GA', 'solana', false),
('EqrDMeFK71ZwqwofejptNgWBmW9FrpqRifa25rcoAr7j', 'solana', false),
('4nZywWNLuTxtsPyfBEgGV3z3chqmKT6ubpCTRVundcBP', 'solana', false),
('CM6SdqwfsswBVJjvdfnsckxq1oH8YfEE3AxW4egcmg6j', 'solana', false),
('71sbrui6JJg9JWEdTRxmmWnBKeM2T2rdgyR4s5VDRc9E', 'solana', false),
('GXr2TdaoEFM3jrr3coi52y44NNxAAhZFmEexjgcvhoar', 'solana', false),
('8agm3sezWKEpC9BdLg4vmpDe3K5eMx1FdXXV6nJX1ieH', 'solana', false),
('2v5y4n6nbizMEJdYzWWNcqPgCJVEEwC9ZmMkTps8MocW', 'solana', false),
('HJXQFkx5rudMGKFXk7TUNWJseXcm1t36VGzdQh9bpZno', 'solana', false),
('J9hgzfLNfULEYnfHRLxR2XApCj4i8jU3jesCAuSdxap9', 'solana', false),
('x9cfrmMJjDQg57amM5HsKRs7mzNfFBu7K85tP3g2V8k', 'solana', false),
('DHvuRq11YwZhUsb1XMzm6p5T6JvNBV9ZgcMUtNPwyto', 'solana', false),
('9qJSC7JKKMMFsfxyeDj2NQKSh5XdhJQTkw8PD8cks8Yy', 'solana', false),
('3D89fLL6NzwBvv938Dg6DZix5kKH3dWdF4FUmzkdfMHr', 'solana', false),
('2MJSuDfv35vkGmQjZdgk1TcRQVkoTVSyuriBWEJftrFa', 'solana', false),
('EjzTo8PheDZAnEsdH4AZUHj2daK7QUicmoTckCedqfub', 'solana', false),
('52kK2z9GuUfHkshazgimcqUGs6izETcQaNWfycF2JjCZ', 'solana', false),
('1CSbunR1LPo1pEMoYbYjfe1kvgScVudytCsbGiEGZRd', 'solana', false),
('9D3dZdhf86YytD1vC47LPqeDMac3j7mXgPUtzwFFhq2b', 'solana', false),
('BXBm2M9iowFfBL9GtsBYG8i9VtuqnQK6RupKY2kixYaP', 'solana', false),
('4tKhDYdBKLEet6xT21sHSFZGUREV2o8MhAvVjGqsEo38', 'solana', false),
('A3rzH4wttgcGYi2SFum5xe5CuygzYuAJGUCaBdAjFHxh', 'solana', false),
('E1dLseJ54AnkftFfkwzmzS3QPmjqjgLcu1RPypsoNDbg', 'solana', false),
('BCQ4jDAA1ptt9KqqPKMMrUTwXHvkiRmiFCYyxw17jeNo', 'solana', false),
('8xg4FYEMUas7XYcyt4VhGVLCGezNXWmDjMZ2SKzRbEru', 'solana', false),
('3UppRiEYUwZxAJXhi1zM5qwBcgKMJKFYJSZuJpyHsDwL', 'solana', false),
('F1kANUTU9LRmraGhjHZWpXdfETxoBUSBcwEm6yb7owb8', 'solana', false),
('8EfKGH5dA2RnwDdiWYs3hDCTfcsALJiwAndqgNGK6KVD', 'solana', false),
('Em7oW6ZLgFfWqNJRiGCdVWReWvg5F6wzvZJyNcESS7PM', 'solana', false),
('9sg2nUmscp5erZRBAGc8XPibnii2b7Hu6HCcW3qLzyci', 'solana', false),
('859XvvkLWEwDcvkcdDKs6fzbAhtEJJJuYVENVsnxa4bh', 'solana', false),
('4juqgZDjZhrvaSimqTQkwp21sxJ16dwdN3DWoom3X9GH', 'solana', false),
('EMVUtghcuvkBQhR1STEt31ktJYDH2dpSjtULgSvFKVPu', 'solana', false),
('Et4YKkVKa1sPfTZaukHr6taU5oRgMjR6vkHm2J2iBF5z', 'solana', false),
('FrtjT3BPVNE6uALu9G54nQ4qqDvMapTzPrqAdj2tAy5h', 'solana', false),
('AJLkK4K7xjGRuE7xvNVcjzwCpoWM93uGLoNBoe58wfdJ', 'solana', false),
('EnihMix7ZWWFvFkTfsbELVhPuGnU9WNaBwHPrSxePKpJ', 'solana', false),
('HGdobZBpF6vQRXPu23UNwp2Qpn5rLesbgucJTfAVvhM5', 'solana', false),
('HVLRWbXgxbeacZfbL89ogeywJm9WQ3ErF9YQeK8ioePp', 'solana', false),
('DhdajAjsU51yh5qkPgQ73oGGKkctjLNAktmhMdr8XRG7', 'solana', false),
('7WvVx8BQ9sueMu1kafhj2ayJMsFR7p7AZycft9yE1K3S', 'solana', false),
('Aoir5VtAkvjnz2ufQPu4jQ4UVPnZKXUZRQTsEnwtb7fw', 'solana', false);

-- Drop old trigger and function
DROP TRIGGER IF EXISTS assign_addresses_on_profile_creation ON profiles;
DROP FUNCTION IF EXISTS auto_assign_crypto_addresses();

-- Create new function to assign addresses by section
CREATE OR REPLACE FUNCTION auto_assign_crypto_addresses_by_section()
RETURNS TRIGGER AS $$
DECLARE
    available_section_id integer;
    available_solana_address text;
BEGIN
    -- Find the first available section (has both ETH and TRX addresses unassigned)
    SELECT section_id INTO available_section_id
    FROM crypto_addresses 
    WHERE section_id IS NOT NULL 
      AND is_assigned = false
    GROUP BY section_id
    HAVING COUNT(*) = 2  -- Must have both ETH and TRX addresses
    ORDER BY section_id
    LIMIT 1;
    
    -- Find first available Solana address
    SELECT address INTO available_solana_address
    FROM crypto_addresses
    WHERE network = 'solana' 
      AND is_assigned = false
      AND section_id IS NULL
    ORDER BY created_at
    LIMIT 1;
    
    -- If we have both section and solana address available
    IF available_section_id IS NOT NULL AND available_solana_address IS NOT NULL THEN
        -- Mark the section addresses as assigned
        UPDATE crypto_addresses 
        SET is_assigned = true 
        WHERE section_id = available_section_id;
        
        -- Mark the solana address as assigned
        UPDATE crypto_addresses 
        SET is_assigned = true 
        WHERE address = available_solana_address;
        
        -- Create user wallet record
        INSERT INTO user_wallets (user_id, section_id, solana_address)
        VALUES (NEW.id, available_section_id, available_solana_address);
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new trigger
CREATE TRIGGER assign_addresses_on_profile_creation
    AFTER INSERT ON profiles
    FOR EACH ROW
    EXECUTE FUNCTION auto_assign_crypto_addresses_by_section();

-- Create function to get user addresses
CREATE OR REPLACE FUNCTION get_user_crypto_addresses(target_user_id uuid)
RETURNS TABLE (
    ethereum_address text,
    tron_address text,
    solana_address text
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        eth.address as ethereum_address,
        trx.address as tron_address,
        uw.solana_address
    FROM user_wallets uw
    LEFT JOIN crypto_addresses eth ON eth.section_id = uw.section_id AND eth.network = 'ethereum'
    LEFT JOIN crypto_addresses trx ON trx.section_id = uw.section_id AND trx.network = 'tron'
    WHERE uw.user_id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update RLS policies for new structure
DROP POLICY IF EXISTS "Users can read own wallet" ON user_wallets;
CREATE POLICY "Users can read own wallet" ON user_wallets
    FOR SELECT USING (user_id = auth.uid());

-- Add RLS policy for the new function
GRANT EXECUTE ON FUNCTION get_user_crypto_addresses(uuid) TO authenticated;