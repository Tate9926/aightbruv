/*
  # Update Solana minimum withdrawal to 0.001 SOL

  1. Changes
    - Update withdrawal validation function to allow 0.001 SOL minimum for Solana
    - This aligns the backend with the frontend requirement

  2. Security
    - Maintains all existing validation logic
    - Only changes the minimum amount threshold for Solana network
*/

-- Update the withdrawal validation function to allow 0.001 SOL minimum
CREATE OR REPLACE FUNCTION validate_withdrawal_amount()
RETURNS TRIGGER AS $$
BEGIN
  -- Check minimum withdrawal amounts by network
  IF NEW.network = 'ethereum' AND NEW.amount < 0.0001 THEN
    RAISE EXCEPTION 'Minimum Ethereum withdrawal is 0.0001 ETH';
  END IF;
  
  IF NEW.network = 'tron' AND NEW.amount < 1 THEN
    RAISE EXCEPTION 'Minimum Tron withdrawal is 1 TRX';
  END IF;
  
  IF NEW.network = 'solana' AND NEW.amount < 0.001 THEN
    RAISE EXCEPTION 'Minimum Solana withdrawal is 0.001 SOL';
  END IF;
  
  -- Check if user has sufficient balance
  DECLARE
    user_balance NUMERIC;
  BEGIN
    SELECT balance INTO user_balance
    FROM profiles
    WHERE id = NEW.user_id;
    
    IF user_balance < NEW.usd_amount THEN
      RAISE EXCEPTION 'Insufficient balance. Available: $%, Required: $%', 
        user_balance, NEW.usd_amount;
    END IF;
  END;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;