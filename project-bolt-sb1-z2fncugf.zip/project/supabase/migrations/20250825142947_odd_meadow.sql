/*
  # Add balance column to profiles table

  1. Schema Changes
    - Add `balance` column to `profiles` table with default value of 0.00
    - This will track the user's actual spendable balance separate from total_winnings
    - total_winnings remains as a metric for tracking lifetime earnings

  2. Data Migration
    - Initialize all existing users' balance to 0.00
    - In production, you might want to migrate total_winnings to balance if appropriate

  3. Important Notes
    - balance represents the user's current spendable funds
    - total_winnings represents lifetime earnings and should not be modified for withdrawals
    - Deposits should increase balance
    - Withdrawals should decrease balance
    - Game winnings should increase both balance and total_winnings
*/

-- Add balance column to profiles table
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS balance NUMERIC(10,2) DEFAULT 0.00 NOT NULL;

-- Add a check constraint to ensure balance is never negative
ALTER TABLE profiles 
ADD CONSTRAINT profiles_balance_check CHECK (balance >= 0);

-- Create an index on balance for faster queries
CREATE INDEX IF NOT EXISTS profiles_balance_idx ON profiles(balance);

-- Update the RLS policies to include the new balance column
-- (The existing policies should already cover this, but we'll make sure)

-- Add a comment to document the difference between balance and total_winnings
COMMENT ON COLUMN profiles.balance IS 'Current spendable balance for withdrawals and betting';
COMMENT ON COLUMN profiles.total_winnings IS 'Lifetime total winnings earned from games (display only)';