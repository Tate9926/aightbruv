/*
  # Game Database Schema

  1. New Tables
    - `profiles` - User profiles with total winnings
    - `game_servers` - Game servers with player count tracking
    - `game_sessions` - Individual game sessions
    - `leaderboard` - Top players leaderboard
    - `server_players` - Players currently in servers

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Secure data access based on user roles

  3. Real-time Features
    - Server player count updates
    - Leaderboard updates
    - Global winnings tracking
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Profiles table for user data
CREATE TABLE IF NOT EXISTS profiles (
  id uuid REFERENCES auth.users(id) PRIMARY KEY,
  username text UNIQUE NOT NULL,
  total_winnings decimal(10,2) DEFAULT 0.00,
  games_played integer DEFAULT 0,
  games_won integer DEFAULT 0,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Game servers table
CREATE TABLE IF NOT EXISTS game_servers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  server_name text NOT NULL,
  current_players integer DEFAULT 0,
  max_players integer DEFAULT 30,
  status text DEFAULT 'waiting' CHECK (status IN ('waiting', 'playing', 'finished')),
  bet_amount decimal(10,2) NOT NULL,
  prize_pool decimal(10,2) DEFAULT 0.00,
  created_at timestamptz DEFAULT now(),
  started_at timestamptz,
  finished_at timestamptz
);

-- Game sessions for individual games
CREATE TABLE IF NOT EXISTS game_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  server_id uuid REFERENCES game_servers(id) ON DELETE CASCADE,
  player_id uuid REFERENCES profiles(id),
  position integer,
  winnings decimal(10,2) DEFAULT 0.00,
  snake_data jsonb,
  joined_at timestamptz DEFAULT now(),
  finished_at timestamptz
);

-- Server players for real-time tracking
CREATE TABLE IF NOT EXISTS server_players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  server_id uuid REFERENCES game_servers(id) ON DELETE CASCADE,
  player_id uuid REFERENCES profiles(id),
  snake_position jsonb DEFAULT '{"x": 10, "y": 10}',
  snake_body jsonb DEFAULT '[{"x": 10, "y": 10}]',
  score integer DEFAULT 0,
  is_alive boolean DEFAULT true,
  joined_at timestamptz DEFAULT now()
);

-- Leaderboard view
CREATE OR REPLACE VIEW leaderboard AS
SELECT 
  p.id,
  p.username,
  p.total_winnings,
  p.games_played,
  p.games_won,
  CASE 
    WHEN p.games_played > 0 
    THEN ROUND((p.games_won::decimal / p.games_played::decimal) * 100, 2)
    ELSE 0 
  END as win_rate
FROM profiles p
ORDER BY p.total_winnings DESC
LIMIT 10;

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_servers ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE server_players ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can read all profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Game servers policies
CREATE POLICY "Anyone can read game servers"
  ON game_servers
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can manage game servers"
  ON game_servers
  FOR ALL
  TO authenticated
  USING (true);

-- Game sessions policies
CREATE POLICY "Users can read own game sessions"
  ON game_sessions
  FOR SELECT
  TO authenticated
  USING (player_id = auth.uid());

CREATE POLICY "Users can insert own game sessions"
  ON game_sessions
  FOR INSERT
  TO authenticated
  WITH CHECK (player_id = auth.uid());

-- Server players policies
CREATE POLICY "Users can read server players"
  ON server_players
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage own server presence"
  ON server_players
  FOR ALL
  TO authenticated
  USING (player_id = auth.uid());

-- Functions for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Function to get or create available server
CREATE OR REPLACE FUNCTION get_or_create_server(bet_amount_param decimal)
RETURNS uuid AS $$
DECLARE
  server_id uuid;
BEGIN
  -- Try to find an available server
  SELECT id INTO server_id
  FROM game_servers
  WHERE current_players < max_players 
    AND status = 'waiting'
    AND bet_amount = bet_amount_param
  ORDER BY created_at ASC
  LIMIT 1;
  
  -- If no server found, create a new one
  IF server_id IS NULL THEN
    INSERT INTO game_servers (server_name, bet_amount, prize_pool)
    VALUES (
      'Server ' || EXTRACT(EPOCH FROM now())::text,
      bet_amount_param,
      0.00
    )
    RETURNING id INTO server_id;
  END IF;
  
  RETURN server_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;