/*
  # Add account index to profiles for HD wallet derivation

  1. New Column
    - `account_index` (integer) - HD wallet derivation index for each user
  
  2. Function
    - Auto-assign account index on profile creation
  
  3. Security
    - Ensures each user gets unique wallet addresses from master mnemonic
*/

-- Add account_index column to profiles
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS account_index integer;

-- Create function to auto-assign account index
CREATE OR REPLACE FUNCTION assign_account_index()
RETURNS TRIGGER AS $$
BEGIN
  -- Get the next available account index
  SELECT COALESCE(MAX(account_index), -1) + 1 
  INTO NEW.account_index 
  FROM profiles;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to auto-assign account index on profile creation
DROP TRIGGER IF EXISTS assign_account_index_trigger ON profiles;
CREATE TRIGGER assign_account_index_trigger
  BEFORE INSERT ON profiles
  FOR EACH ROW
  WHEN (NEW.account_index IS NULL)
  EXECUTE FUNCTION assign_account_index();

-- Update existing profiles without account_index
DO $$
DECLARE
  profile_record RECORD;
  current_index integer := 0;
BEGIN
  FOR profile_record IN 
    SELECT id FROM profiles 
    WHERE account_index IS NULL 
    ORDER BY created_at ASC
  LOOP
    UPDATE profiles 
    SET account_index = current_index 
    WHERE id = profile_record.id;
    
    current_index := current_index + 1;
  END LOOP;
END $$;