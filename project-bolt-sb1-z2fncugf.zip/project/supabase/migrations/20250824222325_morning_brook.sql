/*
  # Add User Statistics Tables

  1. New Tables
    - `user_statistics`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to profiles)
      - `total_play_time` (integer, seconds)
      - `total_eliminations` (integer)
      - `avg_survival_time` (numeric, seconds)
      - `kills_per_game` (numeric)
      - `longest_survival` (integer, seconds)
      - `best_score` (integer)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `daily_game_stats`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to profiles)
      - `date` (date)
      - `games_played` (integer)
      - `games_won` (integer)
      - `total_earnings` (numeric)
      - `total_eliminations` (integer)
      - `total_play_time` (integer, seconds)
      - `avg_survival_time` (numeric, seconds)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for users to read/update own stats
    
  3. Functions
    - Function to update user statistics after each game
    - Function to get user statistics for charts
*/

-- Create user_statistics table
CREATE TABLE IF NOT EXISTS user_statistics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  total_play_time integer DEFAULT 0,
  total_eliminations integer DEFAULT 0,
  avg_survival_time numeric(10,2) DEFAULT 0.00,
  kills_per_game numeric(10,2) DEFAULT 0.00,
  longest_survival integer DEFAULT 0,
  best_score integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Create daily_game_stats table
CREATE TABLE IF NOT EXISTS daily_game_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  date date DEFAULT CURRENT_DATE,
  games_played integer DEFAULT 0,
  games_won integer DEFAULT 0,
  total_earnings numeric(10,2) DEFAULT 0.00,
  total_eliminations integer DEFAULT 0,
  total_play_time integer DEFAULT 0,
  avg_survival_time numeric(10,2) DEFAULT 0.00,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, date)
);

-- Enable RLS
ALTER TABLE user_statistics ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_game_stats ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_statistics
CREATE POLICY "Users can read own statistics"
  ON user_statistics
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own statistics"
  ON user_statistics
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own statistics"
  ON user_statistics
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

-- RLS Policies for daily_game_stats
CREATE POLICY "Users can read own daily stats"
  ON daily_game_stats
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own daily stats"
  ON daily_game_stats
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own daily stats"
  ON daily_game_stats
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

-- Function to update user statistics after a game
CREATE OR REPLACE FUNCTION update_user_game_statistics(
  p_user_id uuid,
  p_survival_time integer,
  p_eliminations integer,
  p_score integer,
  p_won boolean,
  p_earnings numeric DEFAULT 0
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_stats record;
  new_avg_survival numeric;
  new_kills_per_game numeric;
BEGIN
  -- Get current user statistics
  SELECT * INTO current_stats
  FROM user_statistics
  WHERE user_id = p_user_id;
  
  -- If no stats exist, create initial record
  IF current_stats IS NULL THEN
    INSERT INTO user_statistics (
      user_id,
      total_play_time,
      total_eliminations,
      avg_survival_time,
      kills_per_game,
      longest_survival,
      best_score
    ) VALUES (
      p_user_id,
      p_survival_time,
      p_eliminations,
      p_survival_time,
      p_eliminations,
      p_survival_time,
      p_score
    );
  ELSE
    -- Calculate new averages
    new_avg_survival := (
      (current_stats.avg_survival_time * (SELECT games_played FROM profiles WHERE id = p_user_id)) + p_survival_time
    ) / ((SELECT games_played FROM profiles WHERE id = p_user_id) + 1);
    
    new_kills_per_game := (
      current_stats.total_eliminations + p_eliminations
    ) / ((SELECT games_played FROM profiles WHERE id = p_user_id) + 1);
    
    -- Update user statistics
    UPDATE user_statistics SET
      total_play_time = total_play_time + p_survival_time,
      total_eliminations = total_eliminations + p_eliminations,
      avg_survival_time = new_avg_survival,
      kills_per_game = new_kills_per_game,
      longest_survival = GREATEST(longest_survival, p_survival_time),
      best_score = GREATEST(best_score, p_score),
      updated_at = now()
    WHERE user_id = p_user_id;
  END IF;
  
  -- Update or insert daily stats
  INSERT INTO daily_game_stats (
    user_id,
    date,
    games_played,
    games_won,
    total_earnings,
    total_eliminations,
    total_play_time,
    avg_survival_time
  ) VALUES (
    p_user_id,
    CURRENT_DATE,
    1,
    CASE WHEN p_won THEN 1 ELSE 0 END,
    p_earnings,
    p_eliminations,
    p_survival_time,
    p_survival_time
  )
  ON CONFLICT (user_id, date)
  DO UPDATE SET
    games_played = daily_game_stats.games_played + 1,
    games_won = daily_game_stats.games_won + CASE WHEN p_won THEN 1 ELSE 0 END,
    total_earnings = daily_game_stats.total_earnings + p_earnings,
    total_eliminations = daily_game_stats.total_eliminations + p_eliminations,
    total_play_time = daily_game_stats.total_play_time + p_survival_time,
    avg_survival_time = (daily_game_stats.avg_survival_time * daily_game_stats.games_played + p_survival_time) / (daily_game_stats.games_played + 1),
    updated_at = now();
END;
$$;

-- Function to get user chart data
CREATE OR REPLACE FUNCTION get_user_chart_data(p_user_id uuid, p_days integer DEFAULT 30)
RETURNS TABLE (
  date date,
  games_played integer,
  games_won integer,
  total_earnings numeric,
  total_eliminations integer,
  total_play_time integer,
  avg_survival_time numeric,
  win_rate numeric
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    dgs.date,
    dgs.games_played,
    dgs.games_won,
    dgs.total_earnings,
    dgs.total_eliminations,
    dgs.total_play_time,
    dgs.avg_survival_time,
    CASE 
      WHEN dgs.games_played > 0 THEN (dgs.games_won::numeric / dgs.games_played::numeric) * 100
      ELSE 0
    END as win_rate
  FROM daily_game_stats dgs
  WHERE dgs.user_id = p_user_id
    AND dgs.date >= CURRENT_DATE - INTERVAL '1 day' * p_days
  ORDER BY dgs.date ASC;
END;
$$;

-- Create triggers for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_user_statistics_updated_at
  BEFORE UPDATE ON user_statistics
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_daily_game_stats_updated_at
  BEFORE UPDATE ON daily_game_stats
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert some sample data for existing users
DO $$
DECLARE
  user_record record;
  sample_date date;
  i integer;
BEGIN
  -- For each existing user, create some sample statistics
  FOR user_record IN SELECT id FROM profiles LOOP
    -- Create user statistics record
    INSERT INTO user_statistics (
      user_id,
      total_play_time,
      total_eliminations,
      avg_survival_time,
      kills_per_game,
      longest_survival,
      best_score
    ) VALUES (
      user_record.id,
      3600 + (random() * 7200)::integer, -- 1-3 hours total play time
      50 + (random() * 200)::integer, -- 50-250 total eliminations
      120 + (random() * 180)::numeric, -- 2-5 minutes avg survival
      2.5 + (random() * 3)::numeric, -- 2.5-5.5 kills per game
      300 + (random() * 600)::integer, -- 5-15 minutes longest survival
      1000 + (random() * 4000)::integer -- 1000-5000 best score
    )
    ON CONFLICT (user_id) DO NOTHING;
    
    -- Create daily stats for the last 30 days
    FOR i IN 0..29 LOOP
      sample_date := CURRENT_DATE - INTERVAL '1 day' * i;
      
      -- Only create stats for some days (not every day)
      IF random() > 0.3 THEN
        INSERT INTO daily_game_stats (
          user_id,
          date,
          games_played,
          games_won,
          total_earnings,
          total_eliminations,
          total_play_time,
          avg_survival_time
        ) VALUES (
          user_record.id,
          sample_date,
          1 + (random() * 5)::integer, -- 1-6 games per day
          (random() * 3)::integer, -- 0-3 wins per day
          (random() * 50)::numeric, -- $0-50 earnings per day
          (random() * 15)::integer, -- 0-15 eliminations per day
          600 + (random() * 1800)::integer, -- 10-40 minutes play time
          60 + (random() * 240)::numeric -- 1-5 minutes avg survival
        )
        ON CONFLICT (user_id, date) DO NOTHING;
      END IF;
    END LOOP;
  END LOOP;
END $$;