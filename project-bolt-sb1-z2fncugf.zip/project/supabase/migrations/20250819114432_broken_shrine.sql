/*
  # Fix RLS Policy Issues

  1. Changes
    - Remove overly broad "FOR ALL" policy on server_players table
    - Replace with explicit INSERT, UPDATE, DELETE policies
    - Keep existing SELECT policy for reading all server players
    - This fixes 503 errors when fetching players and global winnings

  2. Security
    - Users can read all server players (for game functionality)
    - Users can only insert/update/delete their own server presence
    - Maintains security while fixing permission conflicts
*/

-- Remove the problematic "FOR ALL" policy
DROP POLICY IF EXISTS "Users can manage own server presence" ON server_players;

-- Add explicit policies for INSERT, UPDATE, DELETE operations
CREATE POLICY "Users can insert own server presence"
  ON server_players
  FOR INSERT
  TO authenticated
  WITH CHECK (player_id = auth.uid());

CREATE POLICY "Users can update own server presence"
  ON server_players
  FOR UPDATE
  TO authenticated
  USING (player_id = auth.uid());

CREATE POLICY "Users can delete own server presence"
  ON server_players
  FOR DELETE
  TO authenticated
  USING (player_id = auth.uid());