/*
  # Create Multi-chain Crypto Wallets System

  1. New Tables
    - `crypto_addresses`
      - `id` (uuid, primary key)
      - `ethereum_address` (text)
      - `tron_address` (text)
      - `solana_address` (text)
      - `is_assigned` (boolean)
      - `created_at` (timestamp)
    - `user_wallets`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `crypto_address_id` (uuid, references crypto_addresses)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for user access

  3. Functions
    - Auto-assign addresses on profile creation
    - Get user crypto addresses function
*/

-- Drop existing tables if they exist
DROP TABLE IF EXISTS user_wallets CASCADE;
DROP TABLE IF EXISTS crypto_addresses CASCADE;
DROP FUNCTION IF EXISTS auto_assign_crypto_addresses() CASCADE;
DROP FUNCTION IF EXISTS get_user_crypto_addresses(uuid) CASCADE;

-- Create crypto_addresses table with all three networks in one row
CREATE TABLE crypto_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ethereum_address text NOT NULL,
  tron_address text NOT NULL,
  solana_address text NOT NULL,
  is_assigned boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create user_wallets table
CREATE TABLE user_wallets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  crypto_address_id uuid REFERENCES crypto_addresses(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE crypto_addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_wallets ENABLE ROW LEVEL SECURITY;

-- RLS Policies for crypto_addresses
CREATE POLICY "System can manage crypto addresses"
  ON crypto_addresses
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for user_wallets
CREATE POLICY "Users can read own wallet"
  ON user_wallets
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "System can manage user wallets"
  ON user_wallets
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Insert sample crypto addresses (50 complete sets)
INSERT INTO crypto_addresses (ethereum_address, tron_address, solana_address) VALUES
('0x1234567890123456789012345678901234567890', 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t', '6MCvSMpgu7bM5tS1wS5HPrtST3fZfb1NwRp8UYZhyKfc'),
('0x2345678901234567890123456789012345678901', 'TLa2f6VPqDgRE67v1736s7bJ8Ray5wYjU7', '5bnUQiVv3ST8GXQq54oiQy6LfbaEC74j3Y8sbFicQSc8'),
('0x3456789012345678901234567890123456789012', 'TMuA6YgfZeZGiGNKxQyJb2gSuUtcKu5KiD', 'GczBMftDnDGfbbxxhT9PLvtra7yGSzbHL5FcxXv58x9b'),
('0x4567890123456789012345678901234567890123', 'TKzxdSv2FZKQrEqkKh3rPsnhjXxDF1GYaX', 'GtmoTTcuFbWxqk4AXMpCNv8KfbyR61fUeD6J8PN2GhGE'),
('0x5678901234567890123456789012345678901234', 'TYASr923SHXxoqiPqwbfeQYHLnRKpHuAS1', 'AtJpTTbX3sGhDb7a9DxfcBk1ZaUTGa9wLj8fhFbgJC7S'),
('0x6789012345678901234567890123456789012345', 'TG3XXyExBkPp3nzdVxbWUbz3keoSbMzMBF', '2FSki4MiXmRkfYmzw3uNogMfyVW6w9QysFvc6KFpbS2R'),
('0x7890123456789012345678901234567890123456', 'THPvaUhoh2Qn2PIJ4tz6UWKiH4EM9jCDpD', '9RcHVFqmaKsNecDJgA5XjYrgHgKytyniu8zANhKtgKfC'),
('0x8901234567890123456789012345678901234567', 'TQn9Y2khR7FJwDdxFy4hVx3P8nKpfgpqS1', '2JDav5YSM15MDF8hDpwtcBC9F1GWh9Y8x1PzAYr2rZ2t'),
('0x9012345678901234567890123456789012345678', 'TLyqzVGLuF6SojqxGdEQABjctTqqSeMkzD', 'ACTkBxRZHjaWKkLCgvNPdPFexXcAigRKi62SEzLFEgms'),
('0xa123456789012345678901234567890123456789', 'TAUN6FwrnwwmaEqYcckffC7wYmbaS6cBiX', 'EbFdQyiQ4tA6B9Bt1FuRaW1AVrr8MDecRFVQKrfnY7GA'),
('0xb234567890123456789012345678901234567890', 'TKHuVq1oKVruCGLvqVexFs6dawKv6fQgFs', 'EqrDMeFK71ZwqwofejptNgWBmW9FrpqRifa25rcoAr7j'),
('0xc345678901234567890123456789012345678901', 'TYDzsYUEpkLSsZHZKJJbQQmuRPFVCy2KZh', '4nZywWNLuTxtsPyfBEgGV3z3chqmKT6ubpCTRVundcBP'),
('0xd456789012345678901234567890123456789012', 'TBv3AE5Mn7VQjak4bt2RCPVkLgf7DgFoQD', 'CM6SdqwfsswBVJjvdfnsckxq1oH8YfEE3AxW4egcmg6j'),
('0xe567890123456789012345678901234567890123', 'TC1Z8ao9HQCUmBKzzHVXsNWBQzVthPcp6J', '71sbrui6JJg9JWEdTRxmmWnBKeM2T2rdgyR4s5VDRc9E'),
('0xf678901234567890123456789012345678901234', 'TDTtq5ZdpnHZKqyTZH2jPhwDvg2xQs7TVh', 'GXr2TdaoEFM3jrr3coi52y44NNxAAhZFmEexjgcvhoar'),
('0x1789012345678901234567890123456789012345', 'TEY8xn95EfVuS4cxGSGKu3G4JaPaURAMZv', '8agm3sezWKEpC9BdLg4vmpDe3K5eMx1FdXXV6nJX1ieH'),
('0x2890123456789012345678901234567890123456', 'TFczxkVjRRNLtGvW8JCx2qnTazrNKKqAMJ', '2v5y4n6nbizMEJdYzWWNcqPgCJVEEwC9ZmMkTps8MocW'),
('0x3901234567890123456789012345678901234567', 'TGDqQAqFRxoCQDeuvnwyCVNCC6H7PkqFZf', 'HJXQFkx5rudMGKFXk7TUNWJseXcm1t36VGzdQh9bpZno'),
('0x4012345678901234567890123456789012345678', 'THKJn5YVnYHSK3EtxBdqMy8EGKsRLtpVr3', 'J9hgzfLNfULEYnfHRLxR2XApCj4i8jU3jesCAuSdxap9'),
('0x5123456789012345678901234567890123456789', 'TJMSWwzCDLiSkVrRuFDDyQb6BcRkVDHCP6', 'x9cfrmMJjDQg57amM5HsKRs7mzNfFBu7K85tP3g2V8k'),
('0x6234567890123456789012345678901234567890', 'TKNXoP9VfBVGi6vUsWmAgaEGGXmcyDjVjH', 'DHvuRq11YwZhUsb1XMzm6p5T6JvNBV9ZgcMUtNPwyto'),
('0x7345678901234567890123456789012345678901', 'TLOYpQ0WgCWHj7wVtXnBhbFHHYndyEkWjI', '9qJSC7JKKMMFsfxyeDj2NQKSh5XdhJQTkw8PD8cks8Yy'),
('0x8456789012345678901234567890123456789012', 'TMPZqR1XhDXIk8xWuYoCicGIIZoezFlXkJ', '3D89fLL6NzwBvv938Dg6DZix5kKH3dWdF4FUmzkdfMHr'),
('0x9567890123456789012345678901234567890123', 'TNQAsS2YiEYJl9yXvZpDjdHJJapf0GmYlK', '2MJSuDfv35vkGmQjZdgk1TcRQVkoTVSyuriBWEJftrFa'),
('0xa678901234567890123456789012345678901234', 'TORBtT3ZjFZKm0zYwaqEkeFKKbqg1HnZmL', 'EjzTo8PheDZAnEsdH4AZUHj2daK7QUicmoTckCedqfub'),
('0xb789012345678901234567890123456789012345', 'TPSCuU4akGaLn1aZxbrFlgGLLcrh2IoaoM', '52kK2z9GuUfHkshazgimcqUGs6izETcQaNWfycF2JjCZ'),
('0xc890123456789012345678901234567890123456', 'TQTDvV5blHbMo2bZycsFmhHMMdsi3JpbpN', '1CSbunR1LPo1pEMoYbYjfe1kvgScVudytCsbGiEGZRd'),
('0xd901234567890123456789012345678901234567', 'TRUEwW6cmIcNo3cZzdtGniFNNeti4KqcqO', '9D3dZdhf86YytD1vC47LPqeDMac3j7mXgPUtzwFFhq2b'),
('0xe012345678901234567890123456789012345678', 'TSVFxX7dnJdPp4dZ0euHojGOOflj5LrdqP', 'BXBm2M9iowFfBL9GtsBYG8i9VtuqnQK6RupKY2kixYaP'),
('0xf123456789012345678901234567890123456789', 'TTWGyY8eoKePq5eZ1fvIpkHPPgmk6MsesQ', '4tKhDYdBKLEet6xT21sHSFZGUREV2o8MhAvVjGqsEo38'),
('0x1234567890123456789012345678901234567891', 'TUXHzZ9fpLfQr6fZ2gwJqlIPQhnl7NtftR', 'A3rzH4wttgcGYi2SFum5xe5CuygzYuAJGUCaBdAjFHxh'),
('0x2345678901234567890123456789012345678902', 'TVYIaA0gqMgRs7gZ3hxKrmJQQiom8OuguS', 'E1dLseJ54AnkftFfkwzmzS3QPmjqjgLcu1RPypsoNDbg'),
('0x3456789012345678901234567890123456789013', 'TWZJbB1hrNhSt8hZ4iyLsnKRRjpn9PvhvT', 'BCQ4jDAA1ptt9KqqPKMMrUTwXHvkiRmiFCYyxw17jeNo'),
('0x4567890123456789012345678901234567890124', 'TXaKcC2isOiTu9iZ5jzMtoLSSkoq0QwixU', '8xg4FYEMUas7XYcyt4VhGVLCGezNXWmDjMZ2SKzRbEru'),
('0x5678901234567890123456789012345678901235', 'TYbLdD3jtPjUv0jZ6k0NupMTTlpr1RxjyV', '3UppRiEYUwZxAJXhi1zM5qwBcgKMJKFYJSZuJpyHsDwL'),
('0x6789012345678901234567890123456789012346', 'TZcMeE4kuQkVw1kZ7l1OvqNUUmqs2SykzW', 'F1kANUTU9LRmraGhjHZWpXdfETxoBUSBcwEm6yb7owb8'),
('0x7890123456789012345678901234567890123457', 'TadNfF5lvRlWx2lZ8m2PwrOVVnrt3TzlAX', '8EfKGH5dA2RnwDdiWYs3hDCTfcsALJiwAndqgNGK6KVD'),
('0x8901234567890123456789012345678901234568', 'TbeoGG6mwSmXy3mZ9n3QxsPWWosu4U0mBY', 'Em7oW6ZLgFfWqNJRiGCdVWReWvg5F6wzvZJyNcESS7PM'),
('0x9012345678901234567890123456789012345679', 'TcfpHH7nxTnYz4nZ0o4RytQXXptv5V1nCZ', '9sg2nUmscp5erZRBAGc8XPibnii2b7Hu6HCcW3qLzyci'),
('0xa123456789012345678901234567890123456780', 'TdgqII8oyUoZ05oZ1p5SzuRYYquw6W2oDa', '859XvvkLWEwDcvkcdDKs6fzbAhtEJJJuYVENVsnxa4bh'),
('0xb234567890123456789012345678901234567891', 'TehrJJ9pzVpZ16pZ2q6T0vSZZrvx7X3pEb', '4juqgZDjZhrvaSimqTQkwp21sxJ16dwdN3DWoom3X9GH'),
('0xc345678901234567890123456789012345678902', 'TfisKK0q0WqZ27qZ3r7U1wTaaswy8Y4qFc', 'EMVUtghcuvkBQhR1STEt31ktJYDH2dpSjtULgSvFKVPu'),
('0xd456789012345678901234567890123456789013', 'TgjtLL1r1XrZ38rZ4s8V2xUbbtxz9Z5rGd', 'Et4YKkVKa1sPfTZaukHr6taU5oRgMjR6vkHm2J2iBF5z'),
('0xe567890123456789012345678901234567890124', 'ThkuMM2s2YsZ49sZ5t9W3yVccuy0Aa6sHe', 'FrtjT3BPVNE6uALu9G54nQ4qqDvMapTzPrqAdj2tAy5h'),
('0xf678901234567890123456789012345678901235', 'TilvNN3t3ZtZ50tZ6u0X4zWddvz1Bb7tIf', 'AJLkK4K7xjGRuE7xvNVcjzwCpoWM93uGLoNBoe58wfdJ'),
('0x1789012345678901234567890123456789012346', 'TjmwOO4u40uZ61uZ7v1Y5aXeew02Cc8uJg', 'EnihMix7ZWWFvFkTfsbELVhPuGnU9WNaBwHPrSxePKpJ'),
('0x2890123456789012345678901234567890123457', 'TknxPP5v51vZ72vZ8w2Z6bYffx13Dd9vKh', 'HGdobZBpF6vQRXPu23UNwp2Qpn5rLesbgucJTfAVvhM5'),
('0x3901234567890123456789012345678901234568', 'TloyQQ6w62wZ83wZ9x3a7cZggy24Ee0wLi', 'HVLRWbXgxbeacZfbL89ogeywJm9WQ3ErF9YQeK8ioePp'),
('0x4012345678901234567890123456789012345679', 'TmpzRR7x73xZ94xZ0y4b8dahz35Ff1xMj', 'DhdajAjsU51yh5qkPgQ73oGGKkctjLNAktmhMdr8XRG7'),
('0x5123456789012345678901234567890123456780', 'TnqASS8y84yZ05yZ1z5c9ebi046Gg2yNk', '7WvVx8BQ9sueMu1kafhj2ayJMsFR7p7AZycft9yE1K3S');

-- Function to auto-assign crypto addresses when a profile is created
CREATE OR REPLACE FUNCTION auto_assign_crypto_addresses()
RETURNS TRIGGER AS $$
DECLARE
  available_address_id uuid;
BEGIN
  -- Find the first available crypto address
  SELECT id INTO available_address_id
  FROM crypto_addresses
  WHERE is_assigned = false
  ORDER BY created_at ASC
  LIMIT 1;

  -- If we found an available address, assign it
  IF available_address_id IS NOT NULL THEN
    -- Mark the address as assigned
    UPDATE crypto_addresses
    SET is_assigned = true
    WHERE id = available_address_id;

    -- Create user wallet record
    INSERT INTO user_wallets (user_id, crypto_address_id)
    VALUES (NEW.id, available_address_id);
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get user's crypto addresses
CREATE OR REPLACE FUNCTION get_user_crypto_addresses(target_user_id uuid)
RETURNS TABLE (
  ethereum_address text,
  tron_address text,
  solana_address text
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ca.ethereum_address,
    ca.tron_address,
    ca.solana_address
  FROM user_wallets uw
  JOIN crypto_addresses ca ON uw.crypto_address_id = ca.id
  WHERE uw.user_id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to auto-assign addresses when a profile is created
CREATE TRIGGER assign_addresses_on_profile_creation
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION auto_assign_crypto_addresses();

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add updated_at trigger to user_wallets
CREATE TRIGGER update_user_wallets_updated_at
  BEFORE UPDATE ON user_wallets
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();