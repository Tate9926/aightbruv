/*
  # Add real-time triggers and functions

  1. Functions
    - Function to update server player count
    - Function to handle profile updates
  
  2. Triggers
    - Trigger on server_players insert/delete to update server count
    - Enable real-time on all tables
  
  3. Real-time Setup
    - Enable real-time replication for all tables
    - Set up proper RLS policies for real-time access
*/

-- Function to update server player count
CREATE OR REPLACE FUNCTION update_server_player_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE game_servers 
    SET current_players = current_players + 1
    WHERE id = NEW.server_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE game_servers 
    SET current_players = current_players - 1
    WHERE id = OLD.server_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for server player count updates
DROP TRIGGER IF EXISTS update_server_count_trigger ON server_players;
CREATE TRIGGER update_server_count_trigger
  AFTER INSERT OR DELETE ON server_players
  FOR EACH ROW
  EXECUTE FUNCTION update_server_player_count();

-- Function to get or create a server for a specific bet amount
CREATE OR REPLACE FUNCTION get_or_create_server(bet_amount_param DECIMAL)
RETURNS UUID AS $$
DECLARE
  server_id UUID;
BEGIN
  -- Try to find an existing server with space
  SELECT id INTO server_id
  FROM game_servers
  WHERE bet_amount = bet_amount_param
    AND status = 'waiting'
    AND current_players < max_players
  ORDER BY created_at ASC
  LIMIT 1;

  -- If no server found, create a new one
  IF server_id IS NULL THEN
    INSERT INTO game_servers (server_name, bet_amount, status)
    VALUES (
      'Server ' || EXTRACT(EPOCH FROM NOW())::TEXT,
      bet_amount_param,
      'waiting'
    )
    RETURNING id INTO server_id;
  END IF;

  RETURN server_id;
END;
$$ LANGUAGE plpgsql;

-- Enable real-time for all tables
ALTER PUBLICATION supabase_realtime ADD TABLE profiles;
ALTER PUBLICATION supabase_realtime ADD TABLE game_servers;
ALTER PUBLICATION supabase_realtime ADD TABLE server_players;
ALTER PUBLICATION supabase_realtime ADD TABLE game_sessions;

-- Update RLS policies for real-time access
CREATE POLICY "Enable real-time for profiles" ON profiles
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Enable real-time for game_servers" ON game_servers
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Enable real-time for server_players" ON server_players
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Enable real-time for game_sessions" ON game_sessions
  FOR SELECT TO authenticated
  USING (true);