/*
  # Create crypto wallets system

  1. New Tables
    - `crypto_addresses`
      - `id` (uuid, primary key)
      - `address` (text, unique)
      - `network` (text) - ethereum, tron, solana
      - `is_assigned` (boolean, default false)
      - `created_at` (timestamp)
    - `user_wallets`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to profiles)
      - `ethereum_address` (text)
      - `tron_address` (text)
      - `solana_address` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to read their own wallet data
    - Add policies for system to manage address assignment

  3. Functions
    - Function to assign addresses to new users
    - Trigger to auto-assign addresses on user creation
*/

-- Create crypto_addresses table to store all available addresses
CREATE TABLE IF NOT EXISTS crypto_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  address text UNIQUE NOT NULL,
  network text NOT NULL CHECK (network IN ('ethereum', 'tron', 'solana')),
  is_assigned boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create user_wallets table to store assigned addresses per user
CREATE TABLE IF NOT EXISTS user_wallets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  ethereum_address text,
  tron_address text,
  solana_address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE crypto_addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_wallets ENABLE ROW LEVEL SECURITY;

-- RLS Policies for crypto_addresses
CREATE POLICY "System can manage crypto addresses"
  ON crypto_addresses
  FOR ALL
  TO authenticated
  USING (true);

-- RLS Policies for user_wallets
CREATE POLICY "Users can read own wallet"
  ON user_wallets
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "System can manage user wallets"
  ON user_wallets
  FOR ALL
  TO authenticated
  USING (true);

-- Function to assign crypto addresses to a user
CREATE OR REPLACE FUNCTION assign_crypto_addresses_to_user(target_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  eth_addr text;
  tron_addr text;
  sol_addr text;
BEGIN
  -- Get one unassigned address for each network
  SELECT address INTO eth_addr
  FROM crypto_addresses
  WHERE network = 'ethereum' AND is_assigned = false
  ORDER BY created_at ASC
  LIMIT 1;

  SELECT address INTO tron_addr
  FROM crypto_addresses
  WHERE network = 'tron' AND is_assigned = false
  ORDER BY created_at ASC
  LIMIT 1;

  SELECT address INTO sol_addr
  FROM crypto_addresses
  WHERE network = 'solana' AND is_assigned = false
  ORDER BY created_at ASC
  LIMIT 1;

  -- Insert user wallet record
  INSERT INTO user_wallets (user_id, ethereum_address, tron_address, solana_address)
  VALUES (target_user_id, eth_addr, tron_addr, sol_addr)
  ON CONFLICT (user_id) DO UPDATE SET
    ethereum_address = COALESCE(EXCLUDED.ethereum_address, user_wallets.ethereum_address),
    tron_address = COALESCE(EXCLUDED.tron_address, user_wallets.tron_address),
    solana_address = COALESCE(EXCLUDED.solana_address, user_wallets.solana_address),
    updated_at = now();

  -- Mark addresses as assigned
  UPDATE crypto_addresses
  SET is_assigned = true
  WHERE address IN (eth_addr, tron_addr, sol_addr);
END;
$$;

-- Trigger function to auto-assign addresses when profile is created
CREATE OR REPLACE FUNCTION auto_assign_crypto_addresses()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Assign crypto addresses to the new user
  PERFORM assign_crypto_addresses_to_user(NEW.id);
  RETURN NEW;
END;
$$;

-- Create trigger on profiles table
DROP TRIGGER IF EXISTS assign_addresses_on_profile_creation ON profiles;
CREATE TRIGGER assign_addresses_on_profile_creation
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION auto_assign_crypto_addresses();

-- Insert sample Ethereum addresses (you would replace these with real addresses)
INSERT INTO crypto_addresses (address, network) VALUES
('0x1234567890123456789012345678901234567890', 'ethereum'),
('0x2345678901234567890123456789012345678901', 'ethereum'),
('0x3456789012345678901234567890123456789012', 'ethereum'),
('0x4567890123456789012345678901234567890123', 'ethereum'),
('0x5678901234567890123456789012345678901234', 'ethereum'),
('0x6789012345678901234567890123456789012345', 'ethereum'),
('0x7890123456789012345678901234567890123456', 'ethereum'),
('0x8901234567890123456789012345678901234567', 'ethereum'),
('0x9012345678901234567890123456789012345678', 'ethereum'),
('0xa123456789012345678901234567890123456789', 'ethereum')
ON CONFLICT (address) DO NOTHING;

-- Insert sample Tron addresses (you would replace these with real addresses)
INSERT INTO crypto_addresses (address, network) VALUES
('TRX1234567890123456789012345678901234', 'tron'),
('TRX2345678901234567890123456789012345', 'tron'),
('TRX3456789012345678901234567890123456', 'tron'),
('TRX4567890123456789012345678901234567', 'tron'),
('TRX5678901234567890123456789012345678', 'tron'),
('TRX6789012345678901234567890123456789', 'tron'),
('TRX7890123456789012345678901234567890', 'tron'),
('TRX8901234567890123456789012345678901', 'tron'),
('TRX9012345678901234567890123456789012', 'tron'),
('TRXa123456789012345678901234567890123', 'tron')
ON CONFLICT (address) DO NOTHING;

-- Insert Solana addresses from the provided CSV
INSERT INTO crypto_addresses (address, network) VALUES
('6MCvSMpgu7bM5tS1wS5HPrtST3fZfb1NwRp8UYZhyKfc', 'solana'),
('5bnUQiVv3ST8GXQq54oiQy6LfbaEC74j3Y8sbFicQSc8', 'solana'),
('GczBMftDnDGfbbxxhT9PLvtra7yGSzbHL5FcxXv58x9b', 'solana'),
('GtmoTTcuFbWxqk4AXMpCNv8KfbyR61fUeD6J8PN2GhGE', 'solana'),
('AtJpTTbX3sGhDb7a9DxfcBk1ZaUTGa9wLj8fhFbgJC7S', 'solana'),
('2FSki4MiXmRkfYmzw3uNogMfyVW6w9QysFvc6KFpbS2R', 'solana'),
('9RcHVFqmaKsNecDJgA5XjYrgHgKytyniu8zANhKtgKfC', 'solana'),
('2JDav5YSM15MDF8hDpwtcBC9F1GWh9Y8x1PzAYr2rZ2t', 'solana'),
('ACTkBxRZHjaWKkLCgvNPdPFexXcAigRKi62SEzLFEgms', 'solana'),
('EbFdQyiQ4tA6B9Bt1FuRaW1AVrr8MDecRFVQKrfnY7GA', 'solana'),
('EqrDMeFK71ZwqwofejptNgWBmW9FrpqRifa25rcoAr7j', 'solana'),
('4nZywWNLuTxtsPyfBEgGV3z3chqmKT6ubpCTRVundcBP', 'solana'),
('CM6SdqwfsswBVJjvdfnsckxq1oH8YfEE3AxW4egcmg6j', 'solana'),
('71sbrui6JJg9JWEdTRxmmWnBKeM2T2rdgyR4s5VDRc9E', 'solana'),
('GXr2TdaoEFM3jrr3coi52y44NNxAAhZFmEexjgcvhoar', 'solana'),
('8agm3sezWKEpC9BdLg4vmpDe3K5eMx1FdXXV6nJX1ieH', 'solana'),
('2v5y4n6nbizMEJdYzWWNcqPgCJVEEwC9ZmMkTps8MocW', 'solana'),
('HJXQFkx5rudMGKFXk7TUNWJseXcm1t36VGzdQh9bpZno', 'solana'),
('J9hgzfLNfULEYnfHRLxR2XApCj4i8jU3jesCAuSdxap9', 'solana'),
('x9cfrmMJjDQg57amM5HsKRs7mzNfFBu7K85tP3g2V8k', 'solana'),
('DHvuRq11YwZhUsb1XMzm6p5T6JvNBV9ZgcMUtNPwyto', 'solana'),
('9qJSC7JKKMMFsfxyeDj2NQKSh5XdhJQTkw8PD8cks8Yy', 'solana'),
('3D89fLL6NzwBvv938Dg6DZix5kKH3dWdF4FUmzkdfMHr', 'solana'),
('2MJSuDfv35vkGmQjZdgk1TcRQVkoTVSyuriBWEJftrFa', 'solana'),
('EjzTo8PheDZAnEsdH4AZUHj2daK7QUicmoTckCedqfub', 'solana'),
('52kK2z9GuUfHkshazgimcqUGs6izETcQaNWfycF2JjCZ', 'solana'),
('1CSbunR1LPo1pEMoYbYjfe1kvgScVudytCsbGiEGZRd', 'solana'),
('9D3dZdhf86YytD1vC47LPqeDMac3j7mXgPUtzwFFhq2b', 'solana'),
('BXBm2M9iowFfBL9GtsBYG8i9VtuqnQK6RupKY2kixYaP', 'solana'),
('4tKhDYdBKLEet6xT21sHSFZGUREV2o8MhAvVjGqsEo38', 'solana'),
('A3rzH4wttgcGYi2SFum5xe5CuygzYuAJGUCaBdAjFHxh', 'solana'),
('E1dLseJ54AnkftFfkwzmzS3QPmjqjgLcu1RPypsoNDbg', 'solana'),
('BCQ4jDAA1ptt9KqqPKMMrUTwXHvkiRmiFCYyxw17jeNo', 'solana'),
('8xg4FYEMUas7XYcyt4VhGVLCGezNXWmDjMZ2SKzRbEru', 'solana'),
('3UppRiEYUwZxAJXhi1zM5qwBcgKMJKFYJSZuJpyHsDwL', 'solana'),
('F1kANUTU9LRmraGhjHZWpXdfETxoBUSBcwEm6yb7owb8', 'solana'),
('8EfKGH5dA2RnwDdiWYs3hDCTfcsALJiwAndqgNGK6KVD', 'solana'),
('Em7oW6ZLgFfWqNJRiGCdVWReWvg5F6wzvZJyNcESS7PM', 'solana'),
('9sg2nUmscp5erZRBAGc8XPibnii2b7Hu6HCcW3qLzyci', 'solana'),
('859XvvkLWEwDcvkcdDKs6fzbAhtEJJJuYVENVsnxa4bh', 'solana'),
('4juqgZDjZhrvaSimqTQkwp21sxJ16dwdN3DWoom3X9GH', 'solana'),
('EMVUtghcuvkBQhR1STEt31ktJYDH2dpSjtULgSvFKVPu', 'solana'),
('Et4YKkVKa1sPfTZaukHr6taU5oRgMjR6vkHm2J2iBF5z', 'solana'),
('FrtjT3BPVNE6uALu9G54nQ4qqDvMapTzPrqAdj2tAy5h', 'solana'),
('AJLkK4K7xjGRuE7xvNVcjzwCpoWM93uGLoNBoe58wfdJ', 'solana'),
('EnihMix7ZWWFvFkTfsbELVhPuGnU9WNaBwHPrSxePKpJ', 'solana'),
('HGdobZBpF6vQRXPu23UNwp2Qpn5rLesbgucJTfAVvhM5', 'solana'),
('HVLRWbXgxbeacZfbL89ogeywJm9WQ3ErF9YQeK8ioePp', 'solana'),
('DhdajAjsU51yh5qkPgQ73oGGKkctjLNAktmhMdr8XRG7', 'solana'),
('7WvVx8BQ9sueMu1kafhj2ayJMsFR7p7AZycft9yE1K3S', 'solana'),
('Aoir5VtAkvjnz2ufQPu4jQ4UVPnZKXUZRQTsEnwtb7fw', 'solana')
ON CONFLICT (address) DO NOTHING;