/*
  # Transaction Indexer System

  1. New Tables
    - `processed_blocks` - Track which blocks have been processed for each network
    - `pending_deposits` - Queue deposits for processing
    - `deposit_transactions` - Record all deposit transactions
    
  2. Security
    - Enable RLS on all tables
    - Add policies for system access
    
  3. Indexes
    - Optimize for transaction lookups and block processing
    
  4. Functions
    - Helper functions for deposit processing
*/

-- Table to track processed blocks for each network
CREATE TABLE IF NOT EXISTS processed_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  network text NOT NULL CHECK (network IN ('ethereum', 'tron', 'solana')),
  block_number bigint NOT NULL,
  block_hash text NOT NULL,
  processed_at timestamptz DEFAULT now(),
  transaction_count integer DEFAULT 0,
  deposits_found integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Unique constraint to prevent duplicate block processing
CREATE UNIQUE INDEX IF NOT EXISTS processed_blocks_network_block_idx 
ON processed_blocks (network, block_number);

-- Index for efficient querying
CREATE INDEX IF NOT EXISTS processed_blocks_network_processed_at_idx 
ON processed_blocks (network, processed_at DESC);

-- Table for pending deposits (queue system)
CREATE TABLE IF NOT EXISTS pending_deposits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  network text NOT NULL CHECK (network IN ('ethereum', 'tron', 'solana')),
  transaction_hash text NOT NULL,
  from_address text NOT NULL,
  to_address text NOT NULL,
  amount_crypto numeric(20, 8) NOT NULL CHECK (amount_crypto > 0),
  amount_usd numeric(10, 2) NOT NULL CHECK (amount_usd > 0),
  block_number bigint NOT NULL,
  block_hash text NOT NULL,
  confirmations integer DEFAULT 0,
  required_confirmations integer DEFAULT 1,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'credited', 'failed')),
  created_at timestamptz DEFAULT now(),
  confirmed_at timestamptz,
  credited_at timestamptz,
  error_message text
);

-- Indexes for efficient processing
CREATE INDEX IF NOT EXISTS pending_deposits_status_idx ON pending_deposits (status);
CREATE INDEX IF NOT EXISTS pending_deposits_network_idx ON pending_deposits (network);
CREATE INDEX IF NOT EXISTS pending_deposits_user_id_idx ON pending_deposits (user_id);
CREATE INDEX IF NOT EXISTS pending_deposits_tx_hash_idx ON pending_deposits (transaction_hash);
CREATE UNIQUE INDEX IF NOT EXISTS pending_deposits_unique_tx_idx ON pending_deposits (network, transaction_hash);

-- Table for completed deposit transactions (audit trail)
CREATE TABLE IF NOT EXISTS deposit_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  network text NOT NULL CHECK (network IN ('ethereum', 'tron', 'solana')),
  transaction_hash text NOT NULL,
  from_address text NOT NULL,
  to_address text NOT NULL,
  amount_crypto numeric(20, 8) NOT NULL CHECK (amount_crypto > 0),
  amount_usd numeric(10, 2) NOT NULL CHECK (amount_usd > 0),
  block_number bigint NOT NULL,
  block_hash text NOT NULL,
  confirmations integer NOT NULL,
  credited_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Indexes for audit and reporting
CREATE INDEX IF NOT EXISTS deposit_transactions_user_id_idx ON deposit_transactions (user_id);
CREATE INDEX IF NOT EXISTS deposit_transactions_network_idx ON deposit_transactions (network);
CREATE INDEX IF NOT EXISTS deposit_transactions_created_at_idx ON deposit_transactions (created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS deposit_transactions_unique_tx_idx ON deposit_transactions (network, transaction_hash);

-- Enable RLS
ALTER TABLE processed_blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE pending_deposits ENABLE ROW LEVEL SECURITY;
ALTER TABLE deposit_transactions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for processed_blocks (system access only)
CREATE POLICY "System can manage processed blocks"
  ON processed_blocks
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for pending_deposits
CREATE POLICY "System can manage pending deposits"
  ON pending_deposits
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can read own pending deposits"
  ON pending_deposits
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- RLS Policies for deposit_transactions
CREATE POLICY "System can manage deposit transactions"
  ON deposit_transactions
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can read own deposit transactions"
  ON deposit_transactions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Function to get the latest processed block for a network
CREATE OR REPLACE FUNCTION get_latest_processed_block(network_name text)
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  latest_block bigint;
BEGIN
  SELECT COALESCE(MAX(block_number), 0)
  INTO latest_block
  FROM processed_blocks
  WHERE network = network_name;
  
  RETURN latest_block;
END;
$$;

-- Function to credit user deposit
CREATE OR REPLACE FUNCTION credit_user_deposit(
  p_user_id uuid,
  p_amount_usd numeric,
  p_deposit_id uuid
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_balance numeric;
BEGIN
  -- Get current balance
  SELECT balance INTO current_balance
  FROM profiles
  WHERE id = p_user_id;
  
  IF current_balance IS NULL THEN
    RAISE EXCEPTION 'User not found: %', p_user_id;
  END IF;
  
  -- Update user balance
  UPDATE profiles
  SET 
    balance = balance + p_amount_usd,
    updated_at = now()
  WHERE id = p_user_id;
  
  -- Mark deposit as credited
  UPDATE pending_deposits
  SET 
    status = 'credited',
    credited_at = now()
  WHERE id = p_deposit_id;
  
  RETURN true;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error and mark deposit as failed
    UPDATE pending_deposits
    SET 
      status = 'failed',
      error_message = SQLERRM
    WHERE id = p_deposit_id;
    
    RETURN false;
END;
$$;

-- Function to get user addresses for a specific network
CREATE OR REPLACE FUNCTION get_user_addresses_for_network(network_name text)
RETURNS TABLE(user_id uuid, address text)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    uw.user_id,
    CASE 
      WHEN network_name = 'ethereum' THEN ca.ethereum_address
      WHEN network_name = 'tron' THEN ca.tron_address
      WHEN network_name = 'solana' THEN ca.solana_address
    END as address
  FROM user_wallets uw
  JOIN crypto_addresses ca ON uw.crypto_address_id = ca.id
  WHERE 
    CASE 
      WHEN network_name = 'ethereum' THEN ca.ethereum_address IS NOT NULL
      WHEN network_name = 'tron' THEN ca.tron_address IS NOT NULL
      WHEN network_name = 'solana' THEN ca.solana_address IS NOT NULL
    END;
END;
$$;