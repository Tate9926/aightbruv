/*
  # Fix Crypto Addresses Structure

  1. Changes
    - Drop existing crypto_addresses table and recreate with multi-chain structure
    - Update user_wallets table to reference the new structure
    - Create new trigger function for auto-assignment
    - Add sample data with ETH+TRX pairs

  2. New Structure
    - crypto_addresses: id, ethereum_address, tron_address, is_assigned, created_at
    - user_wallets: user_id, crypto_address_id, solana_address
    - Solana addresses remain individual from your CSV data

  3. Security
    - Enable RLS on both tables
    - Add appropriate policies
*/

-- Drop existing tables and functions
DROP TRIGGER IF EXISTS assign_addresses_on_profile_creation ON profiles;
DROP FUNCTION IF EXISTS auto_assign_crypto_addresses_by_section();
DROP FUNCTION IF EXISTS get_user_crypto_addresses(uuid);

-- Drop existing tables
DROP TABLE IF EXISTS user_wallets CASCADE;
DROP TABLE IF EXISTS crypto_addresses CASCADE;

-- Create new crypto_addresses table with multi-chain structure
CREATE TABLE crypto_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ethereum_address text NOT NULL,
  tron_address text NOT NULL,
  is_assigned boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create user_wallets table
CREATE TABLE user_wallets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  crypto_address_id uuid REFERENCES crypto_addresses(id),
  solana_address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE crypto_addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_wallets ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "System can manage crypto addresses"
  ON crypto_addresses
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can read own wallet"
  ON user_wallets
  FOR SELECT
  TO public
  USING (user_id = auth.uid());

CREATE POLICY "System can manage user wallets"
  ON user_wallets
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Insert sample ETH+TRX address pairs
INSERT INTO crypto_addresses (ethereum_address, tron_address) VALUES
  ('0x1234567890123456789012345678901234567890', 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t'),
  ('0x2345678901234567890123456789012345678901', 'TLa2f6VPqDgRE67v1736s7bJ8Ray5wYjU7'),
  ('0x3456789012345678901234567890123456789012', 'TMuA6YqfCeX8EhbfYEg5y7S4DqzSJireY9'),
  ('0x4567890123456789012345678901234567890123', 'TNo59hQvnKG6b9yW5oCHSf1kBRhHgxaF4k'),
  ('0x5678901234567890123456789012345678901234', 'TPYmHEhy5n8TCEfYGqW2rPxsghSfzghPDn'),
  ('0x6789012345678901234567890123456789012345', 'TQn9Y5sHUZ8P9B7X4VwjRz3L2K6N8M9Q5R'),
  ('0x7890123456789012345678901234567890123456', 'TRa8b7cHJK9L2M3N4P5Q6R7S8T9U0V1W2X'),
  ('0x8901234567890123456789012345678901234567', 'TSb9c8dIKL0M3N4O5P6Q7R8S9T0U1V2W3Y'),
  ('0x9012345678901234567890123456789012345678', 'TTc0d9eJLM1N4O5P6Q7R8S9T0U1V2W3X4Z'),
  ('0x0123456789012345678901234567890123456789', 'TUd1e0fKMN2O5P6Q7R8S9T0U1V2W3X4Y5A');

-- Create Solana addresses array (from your CSV data)
CREATE OR REPLACE FUNCTION get_available_solana_addresses()
RETURNS text[] AS $$
BEGIN
  RETURN ARRAY[
    '6MCvSMpgu7bM5tS1wS5HPrtST3fZfb1NwRp8UYZhyKfc',
    '5bnUQiVv3ST8GXQq54oiQy6LfbaEC74j3Y8sbFicQSc8',
    'GczBMftDnDGfbbxxhT9PLvtra7yGSzbHL5FcxXv58x9b',
    'GtmoTTcuFbWxqk4AXMpCNv8KfbyR61fUeD6J8PN2GhGE',
    'AtJpTTbX3sGhDb7a9DxfcBk1ZaUTGa9wLj8fhFbgJC7S',
    '2FSki4MiXmRkfYmzw3uNogMfyVW6w9QysFvc6KFpbS2R',
    '9RcHVFqmaKsNecDJgA5XjYrgHgKytyniu8zANhKtgKfC',
    '2JDav5YSM15MDF8hDpwtcBC9F1GWh9Y8x1PzAYr2rZ2t',
    'ACTkBxRZHjaWKkLCgvNPdPFexXcAigRKi62SEzLFEgms',
    'EbFdQyiQ4tA6B9Bt1FuRaW1AVrr8MDecRFVQKrfnY7GA',
    'EqrDMeFK71ZwqwofejptNgWBmW9FrpqRifa25rcoAr7j',
    '4nZywWNLuTxtsPyfBEgGV3z3chqmKT6ubpCTRVundcBP',
    'CM6SdqwfsswBVJjvdfnsckxq1oH8YfEE3AxW4egcmg6j',
    '71sbrui6JJg9JWEdTRxmmWnBKeM2T2rdgyR4s5VDRc9E',
    'GXr2TdaoEFM3jrr3coi52y44NNxAAhZFmEexjgcvhoar',
    '8agm3sezWKEpC9BdLg4vmpDe3K5eMx1FdXXV6nJX1ieH',
    '2v5y4n6nbizMEJdYzWWNcqPgCJVEEwC9ZmMkTps8MocW',
    'HJXQFkx5rudMGKFXk7TUNWJseXcm1t36VGzdQh9bpZno',
    'J9hgzfLNfULEYnfHRLxR2XApCj4i8jU3jesCAuSdxap9',
    'x9cfrmMJjDQg57amM5HsKRs7mzNfFBu7K85tP3g2V8k',
    'DHvuRq11YwZhUsb1XMzm6p5T6JvNBV9ZgcMUtNPwyto',
    '9qJSC7JKKMMFsfxyeDj2NQKSh5XdhJQTkw8PD8cks8Yy',
    '3D89fLL6NzwBvv938Dg6DZix5kKH3dWdF4FUmzkdfMHr',
    '2MJSuDfv35vkGmQjZdgk1TcRQVkoTVSyuriBWEJftrFa',
    'EjzTo8PheDZAnEsdH4AZUHj2daK7QUicmoTckCedqfub',
    '52kK2z9GuUfHkshazgimcqUGs6izETcQaNWfycF2JjCZ',
    '1CSbunR1LPo1pEMoYbYjfe1kvgScVudytCsbGiEGZRd',
    '9D3dZdhf86YytD1vC47LPqeDMac3j7mXgPUtzwFFhq2b',
    'BXBm2M9iowFfBL9GtsBYG8i9VtuqnQK6RupKY2kixYaP',
    '4tKhDYdBKLEet6xT21sHSFZGUREV2o8MhAvVjGqsEo38',
    'A3rzH4wttgcGYi2SFum5xe5CuygzYuAJGUCaBdAjFHxh',
    'E1dLseJ54AnkftFfkwzmzS3QPmjqjgLcu1RPypsoNDbg',
    'BCQ4jDAA1ptt9KqqPKMMrUTwXHvkiRmiFCYyxw17jeNo',
    '8xg4FYEMUas7XYcyt4VhGVLCGezNXWmDjMZ2SKzRbEru',
    '3UppRiEYUwZxAJXhi1zM5qwBcgKMJKFYJSZuJpyHsDwL',
    'F1kANUTU9LRmraGhjHZWpXdfETxoBUSBcwEm6yb7owb8',
    '8EfKGH5dA2RnwDdiWYs3hDCTfcsALJiwAndqgNGK6KVD',
    'Em7oW6ZLgFfWqNJRiGCdVWReWvg5F6wzvZJyNcESS7PM',
    '9sg2nUmscp5erZRBAGc8XPibnii2b7Hu6HCcW3qLzyci',
    '859XvvkLWEwDcvkcdDKs6fzbAhtEJJJuYVENVsnxa4bh',
    '4juqgZDjZhrvaSimqTQkwp21sxJ16dwdN3DWoom3X9GH',
    'EMVUtghcuvkBQhR1STEt31ktJYDH2dpSjtULgSvFKVPu',
    'Et4YKkVKa1sPfTZaukHr6taU5oRgMjR6vkHm2J2iBF5z',
    'FrtjT3BPVNE6uALu9G54nQ4qqDvMapTzPrqAdj2tAy5h',
    'AJLkK4K7xjGRuE7xvNVcjzwCpoWM93uGLoNBoe58wfdJ',
    'EnihMix7ZWWFvFkTfsbELVhPuGnU9WNaBwHPrSxePKpJ',
    'HGdobZBpF6vQRXPu23UNwp2Qpn5rLesbgucJTfAVvhM5',
    'HVLRWbXgxbeacZfbL89ogeywJm9WQ3ErF9YQeK8ioePp',
    'DhdajAjsU51yh5qkPgQ73oGGKkctjLNAktmhMdr8XRG7',
    '7WvVx8BQ9sueMu1kafhj2ayJMsFR7p7AZycft9yE1K3S',
    'Aoir5VtAkvjnz2ufQPu4jQ4UVPnZKXUZRQTsEnwtb7fw'
  ];
END;
$$ LANGUAGE plpgsql;

-- Create function to auto-assign crypto addresses
CREATE OR REPLACE FUNCTION auto_assign_crypto_addresses()
RETURNS TRIGGER AS $$
DECLARE
  available_crypto_id uuid;
  available_solana_address text;
  solana_addresses text[];
  used_solana_count integer;
BEGIN
  -- Get the next available crypto address pair (ETH + TRX)
  SELECT id INTO available_crypto_id
  FROM crypto_addresses
  WHERE is_assigned = false
  ORDER BY created_at ASC
  LIMIT 1;

  -- Get available Solana addresses
  solana_addresses := get_available_solana_addresses();
  
  -- Count how many Solana addresses are already used
  SELECT COUNT(*) INTO used_solana_count
  FROM user_wallets
  WHERE solana_address IS NOT NULL;

  -- Get the next available Solana address
  IF used_solana_count < array_length(solana_addresses, 1) THEN
    available_solana_address := solana_addresses[used_solana_count + 1];
  END IF;

  -- If we have both crypto pair and Solana address available
  IF available_crypto_id IS NOT NULL AND available_solana_address IS NOT NULL THEN
    -- Mark the crypto address pair as assigned
    UPDATE crypto_addresses
    SET is_assigned = true
    WHERE id = available_crypto_id;

    -- Create user wallet entry
    INSERT INTO user_wallets (user_id, crypto_address_id, solana_address)
    VALUES (NEW.id, available_crypto_id, available_solana_address);
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to auto-assign addresses on profile creation
CREATE TRIGGER assign_addresses_on_profile_creation
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION auto_assign_crypto_addresses();

-- Create function to get user crypto addresses
CREATE OR REPLACE FUNCTION get_user_crypto_addresses(target_user_id uuid)
RETURNS TABLE(
  ethereum_address text,
  tron_address text,
  solana_address text
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ca.ethereum_address,
    ca.tron_address,
    uw.solana_address
  FROM user_wallets uw
  JOIN crypto_addresses ca ON uw.crypto_address_id = ca.id
  WHERE uw.user_id = target_user_id;
END;
$$ LANGUAGE plpgsql;