import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { network, address, transaction_hash } = await req.json()
    
    console.log(`Manual deposit search for ${network}:`, { address, transaction_hash })

    let deposits = []

    if (network === 'solana') {
      deposits = await findSolanaDeposits(address, transaction_hash)
    } else if (network === 'ethereum') {
      deposits = await findEthereumDeposits(address, transaction_hash)
    } else if (network === 'tron') {
      deposits = await findTronDeposits(address, transaction_hash)
    }

    console.log(`Found ${deposits.length} deposits`)

    // Process each found deposit
    for (const deposit of deposits) {
      // Check if already processed
      const { data: existing } = await supabaseClient
        .from('pending_deposits')
        .select('id')
        .eq('transaction_hash', deposit.transaction_hash)
        .eq('network', network)
        .single()

      if (existing) {
        console.log(`Deposit ${deposit.transaction_hash} already exists`)
        continue
      }

      // Find user by address
      const { data: userAddresses } = await supabaseClient
        .rpc('get_user_addresses_for_network', { network_name: network })

      const userAddress = userAddresses?.find(ua => 
        ua.address.toLowerCase() === deposit.to_address.toLowerCase()
      )

      if (!userAddress) {
        console.log(`No user found for address ${deposit.to_address}`)
        continue
      }

      // Create pending deposit
      const { error } = await supabaseClient
        .from('pending_deposits')
        .insert({
          user_id: userAddress.user_id,
          network: network,
          transaction_hash: deposit.transaction_hash,
          from_address: deposit.from_address,
          to_address: deposit.to_address,
          amount_crypto: deposit.amount_crypto,
          amount_usd: deposit.amount_usd,
          block_number: deposit.block_number,
          block_hash: deposit.block_hash,
          status: 'confirmed',
          confirmed_at: new Date().toISOString(),
          confirmations: deposit.confirmations || 1
        })

      if (error) {
        console.error('Error creating deposit:', error)
      } else {
        console.log(`Created deposit for ${deposit.amount_crypto} ${network.toUpperCase()}`)
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        deposits_found: deposits.length,
        deposits: deposits
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Manual deposit finder error:', error)
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    )
  }
})

async function findSolanaDeposits(address?: string, txHash?: string) {
  const rpcUrl = Deno.env.get('SOLANA_RPC_URL') || 'https://api.mainnet-beta.solana.com'
  const deposits = []

  try {
    if (txHash) {
      // Search by specific transaction hash
      console.log(`Searching for Solana transaction: ${txHash}`)
      
      const response = await fetch(rpcUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 1,
          method: 'getTransaction',
          params: [txHash, {
            encoding: 'json',
            maxSupportedTransactionVersion: 0
          }]
        })
      })

      const data = await response.json()
      
      if (data.result && !data.result.meta?.err) {
        const tx = data.result
        const accountKeys = tx.transaction?.message?.accountKeys || []
        const preBalances = tx.meta?.preBalances || []
        const postBalances = tx.meta?.postBalances || []

        // Find balance increases (received SOL)
        for (let i = 0; i < accountKeys.length && i < preBalances.length && i < postBalances.length; i++) {
          const balanceChange = postBalances[i] - preBalances[i]
          
          if (balanceChange > 10000) { // More than 0.00001 SOL - very low threshold
            const toAddress = accountKeys[i]
            
            // Find sender
            let fromAddress = 'unknown'
            for (let j = 0; j < accountKeys.length && j < preBalances.length && j < postBalances.length; j++) {
              const senderBalanceChange = postBalances[j] - preBalances[j]
              if (senderBalanceChange < -balanceChange * 0.9) {
                fromAddress = accountKeys[j]
                break
              }
            }

            console.log(`Found deposit: ${(balanceChange / 1e9).toFixed(9)} SOL (~$${((balanceChange / 1e9) * 200).toFixed(2)}) to ${toAddress}`)
            deposits.push({
              transaction_hash: txHash,
              from_address: fromAddress,
              to_address: toAddress,
              amount_crypto: balanceChange / 1e9, // Convert lamports to SOL
              amount_usd: (balanceChange / 1e9) * 200, // Approximate USD value
              block_number: tx.slot || 0,
              block_hash: tx.transaction?.message?.recentBlockhash || '',
              confirmations: 32 // Assume finalized
            })
          }
        }
      }
    }

    if (address && !txHash) {
      // Search recent transactions for this address
      console.log(`Searching recent transactions for Solana address: ${address}`)
      
      const response = await fetch(rpcUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 1,
          method: 'getSignaturesForAddress',
          params: [address, { limit: 100 }] // Check more transactions
        })
      })

      const data = await response.json()
      
      if (data.result) {
        console.log(`Found ${data.result.length} transactions for address ${address}`)
        for (const sig of data.result.slice(0, 20)) { // Check last 20 transactions
          if (!sig.err) {
            console.log(`Checking transaction: ${sig.signature}`)
            const txDeposits = await findSolanaDeposits(undefined, sig.signature)
            deposits.push(...txDeposits.filter(d => d.to_address === address))
          }
        }
      }
    }

  } catch (error) {
    console.error('Error finding Solana deposits:', error)
  }

  return deposits
}

async function findEthereumDeposits(address?: string, txHash?: string) {
  const rpcUrl = Deno.env.get('ETHEREUM_RPC_URL')
  if (!rpcUrl) return []

  const deposits = []

  try {
    if (txHash) {
      const response = await fetch(rpcUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          method: 'eth_getTransactionByHash',
          params: [txHash],
          id: 1
        })
      })

      const data = await response.json()
      
      if (data.result && data.result.to && data.result.value !== '0x0') {
        const tx = data.result
        const amountEth = parseInt(tx.value, 16) / 1e18
        
        deposits.push({
          transaction_hash: txHash,
          from_address: tx.from,
          to_address: tx.to,
          amount_crypto: amountEth,
          amount_usd: amountEth * 3000, // Approximate USD value
          block_number: parseInt(tx.blockNumber, 16),
          block_hash: tx.blockHash,
          confirmations: 1
        })
      }
    }

  } catch (error) {
    console.error('Error finding Ethereum deposits:', error)
  }

  return deposits
}

async function findTronDeposits(address?: string, txHash?: string) {
  const rpcUrl = Deno.env.get('TRON_RPC_URL') || 'https://api.trongrid.io'
  const deposits = []

  try {
    if (txHash) {
      const response = await fetch(`${rpcUrl}/wallet/gettransactionbyid`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ value: txHash })
      })

      const data = await response.json()
      
      if (data.raw_data?.contract?.[0]?.type === 'TransferContract') {
        const contract = data.raw_data.contract[0].parameter.value
        const amountTrx = contract.amount / 1e6
        
        deposits.push({
          transaction_hash: txHash,
          from_address: contract.owner_address,
          to_address: contract.to_address,
          amount_crypto: amountTrx,
          amount_usd: amountTrx * 0.10, // Approximate USD value
          block_number: 0, // Would need additional call
          block_hash: '',
          confirmations: 1
        })
      }
    }

  } catch (error) {
    console.error('Error finding Tron deposits:', error)
  }

  return deposits
}