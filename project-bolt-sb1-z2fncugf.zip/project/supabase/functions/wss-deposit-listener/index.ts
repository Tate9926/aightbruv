import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Global WebSocket connection
let ws: WebSocket | null = null
let isConnected = false
let subscribedAddresses = new Set<string>()
let addressToUserMap = new Map<string, string>()

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    console.log('🚀 WebSocket Deposit Listener triggered at', new Date().toISOString())

    // If WebSocket isn't connected, start it
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      console.log('🔌 Starting WebSocket connection...')
      await startWebSocketConnection(supabaseClient)
    }

    // Load and subscribe to addresses
    await loadAndSubscribeAddresses(supabaseClient)

    return new Response(
      JSON.stringify({ 
        success: true,
        message: 'WebSocket deposit listener active',
        connected: isConnected,
        subscribedAddresses: subscribedAddresses.size,
        timestamp: new Date().toISOString()
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('❌ WebSocket listener error:', error)
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    )
  }
})

async function startWebSocketConnection(supabaseClient: any) {
  try {
    const wsUrl = 'wss://lb.drpc.org/solana/AvyFcV4C7Eatu7YOOIJHzKFlwb_Ag4sR8IV_qhnKxixj'
    
    console.log('🔌 Connecting to Solana WebSocket...', wsUrl)
    ws = new WebSocket(wsUrl)

    ws.onopen = () => {
      console.log('✅ WebSocket connected at', new Date().toISOString())
      isConnected = true
    }

    ws.onmessage = async (event) => {
      try {
        console.log('📨 WebSocket message received:', event.data)
        const data = JSON.parse(event.data)
        await handleWebSocketMessage(data, supabaseClient)
      } catch (error) {
        console.error('❌ Error processing WebSocket message:', error)
      }
    }

    ws.onclose = (event) => {
      console.log(`🔌 WebSocket disconnected: ${event.code} - ${event.reason}`)
      isConnected = false
      
      // Attempt to reconnect after 5 seconds
      setTimeout(() => {
        console.log('🔄 Attempting to reconnect...')
        startWebSocketConnection(supabaseClient)
      }, 5000)
    }

    ws.onerror = (error) => {
      console.error('❌ WebSocket error:', error)
      isConnected = false
    }

    // Wait for connection
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Connection timeout')), 10000)
      
      ws!.onopen = () => {
        clearTimeout(timeout)
        console.log('✅ WebSocket connected successfully')
        isConnected = true
        resolve(true)
      }
      
      ws!.onerror = () => {
        clearTimeout(timeout)
        reject(new Error('WebSocket connection failed'))
      }
    })

  } catch (error) {
    console.error('❌ Failed to connect WebSocket:', error)
    throw error
  }
}

async function loadAndSubscribeAddresses(supabaseClient: any) {
  try {
    console.log('📋 Loading user addresses from database...')
    
    const { data: userAddresses, error } = await supabaseClient
      .rpc('get_user_addresses_for_network', { network_name: 'solana' })

    if (error) {
      console.error('❌ Error loading user addresses:', error)
      return
    }

    console.log(`📊 Raw user addresses data:`, userAddresses)

    // Clear existing maps
    addressToUserMap.clear()
    const newAddresses = new Set<string>()

    // Build address mapping
    userAddresses?.forEach((ua: any) => {
      if (ua.address) {
        const address = ua.address.trim()
        newAddresses.add(address)
        addressToUserMap.set(address, ua.user_id)
        console.log(`📍 Loaded address: ${address} -> user: ${ua.user_id}`)
      }
    })

    console.log(`✅ Loaded ${newAddresses.size} user addresses`)

    // Subscribe to new addresses
    if (ws && ws.readyState === WebSocket.OPEN) {
      for (const address of newAddresses) {
        if (!subscribedAddresses.has(address)) {
          await subscribeToAddress(address)
          subscribedAddresses.add(address)
        }
      }
      console.log(`📡 Subscribed to ${subscribedAddresses.size} addresses`)
    } else {
      console.log('⚠️ WebSocket not ready for subscriptions')
    }

  } catch (error) {
    console.error('❌ Error loading user addresses:', error)
  }
}

async function subscribeToAddress(address: string) {
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    console.log('⚠️ WebSocket not ready for subscription')
    return
  }

  try {
    const subscriptionId = Math.floor(Math.random() * 1000000)
    const subscribeMessage = {
      jsonrpc: '2.0',
      id: subscriptionId,
      method: 'accountSubscribe',
      params: [
        address,
        {
          encoding: 'base64',
          commitment: 'confirmed'
        }
      ]
    }

    console.log(`📡 Subscribing to address: ${address}`)
    ws.send(JSON.stringify(subscribeMessage))
    
    // Small delay between subscriptions
    await new Promise(resolve => setTimeout(resolve, 100))

  } catch (error) {
    console.error(`❌ Error subscribing to address ${address}:`, error)
  }
}

async function handleWebSocketMessage(data: any, supabaseClient: any) {
  try {
    console.log('🔍 Processing message:', JSON.stringify(data, null, 2))

    // Handle subscription confirmations
    if (data.result && typeof data.result === 'number') {
      console.log(`✅ Subscription confirmed: ID ${data.id} -> Subscription ${data.result}`)
      return
    }

    // Handle account notifications
    if (data.method === 'accountNotification' && data.params) {
      console.log('💰 Account notification received!')
      const { result, subscription } = data.params
      
      if (result && result.value) {
        const newBalance = result.value.lamports || 0
        console.log(`💰 Balance change detected: ${newBalance} lamports`)
        
        // This is where we'd process the deposit
        // For now, just log it
        console.log(`🎯 DEPOSIT DETECTED! New balance: ${(newBalance / 1e9).toFixed(9)} SOL`)
        
        // TODO: Find the specific address and credit the user
        // This requires better subscription tracking
      }
    }

    // Handle errors
    if (data.error) {
      console.error('❌ WebSocket error response:', data.error)
    }

  } catch (error) {
    console.error('❌ Error handling WebSocket message:', error)
  }
}