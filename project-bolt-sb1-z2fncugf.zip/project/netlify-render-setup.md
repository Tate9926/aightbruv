# 🔗 Using Netlify Frontend + Render Background Workers

## **How It Works:**
- **Frontend:** Stays on Netlify (your current URL)
- **Workers:** Run on Render (deposit detection + auto-transfer)
- **Database:** Supabase (connects to both)

## **Setup Steps:**

### **1. Deploy Workers to Render:**
- Deploy **only the 2 background workers** to Render
- **Skip the frontend web service**
- Workers will run 24/7 detecting deposits

### **2. Update Netlify Environment Variables:**
In your Netlify dashboard → Site Settings → Environment Variables:
```
VITE_SUPABASE_URL = https://lystaruqkfcfxpgdlzvv.supabase.co
VITE_SUPABASE_ANON_KEY = your_anon_key_here
```

### **3. Redeploy Netlify:**
- Trigger a new Netlify build
- Your existing URL will work with Render workers

## **✅ Benefits:**
- Keep your current Netlify URL
- Get professional background workers on Render
- Best of both platforms!

## **🔧 Architecture:**
```
Netlify Frontend (your-site.netlify.app)
    ↓ (connects to)
Supabase Database
    ↑ (updated by)
Render Background Workers
    ↓ (detect deposits)
Blockchain Networks (ETH/TRX/SOL)
```

Your users visit your Netlify URL, but deposits are processed by Render workers!